import axios from 'axios';

const api = axios.create({
  // Usa a variável de ambiente VITE_API_BASE_URL.
  // Se a variável não estiver definida (ex: em ambiente de produção sem build),
  // ele usa 'http://localhost:8080' como fallback.
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080', 
} );

export default api;