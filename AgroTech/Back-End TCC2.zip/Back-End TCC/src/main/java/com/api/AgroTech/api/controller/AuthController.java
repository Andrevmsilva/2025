package com.api.AgroTech.api.controller;

import com.api.AgroTech.domain.model.Cidade;
import com.api.AgroTech.domain.model.Cliente;
import com.api.AgroTech.domain.repository.CidadeRepository;
import com.api.AgroTech.domain.repository.ClienteRepository;
import com.api.AgroTech.dto.LoginRequestDTO;
import com.api.AgroTech.dto.RegisterRequestDTO;
import com.api.AgroTech.dto.ResponseDTO;
import com.api.AgroTech.infra.security.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "http://localhost:5173")
public class AuthController {

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private TokenService tokenService;

    @Autowired
    private CidadeRepository cidadeRepository;

    // LOGIN
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequestDTO body) {
        Optional<Cliente> user = clienteRepository.findByEmail(body.getEmail());

        if (user.isEmpty())
            return ResponseEntity.status(401).body("Usuário não encontrado");

        Cliente cliente = user.get();

        if (!passwordEncoder.matches(body.getPassword(), cliente.getSenha()))
            return ResponseEntity.status(401).body("Credenciais inválidas");

        String token = tokenService.generateToken(cliente);

        return ResponseEntity.ok(new ResponseDTO(
                cliente.getId(),
                cliente.getNome(),
                cliente.getEmail(),
                token
        ));
    }

    // REGISTER
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequestDTO body) {

        if (clienteRepository.findByEmail(body.email()).isPresent()) {
            return ResponseEntity.status(409).body("Email já cadastrado");
        }

        Cliente cliente = new Cliente();
        cliente.setNome(body.nome());
        cliente.setEmail(body.email());
        cliente.setSenha(passwordEncoder.encode(body.senha()));
        cliente.setCpf_cnpj(body.cpf_cnpj());
        cliente.setLogradouro(body.logradouro());
        cliente.setNumero(body.numero());
        cliente.setBairro(body.bairro());
        cliente.setComplemento(body.complemento());

        Cidade cidade = cidadeRepository.findById(body.cidadeId())
                .orElseThrow(() -> new RuntimeException("Cidade não encontrada"));
        cliente.setCidade(cidade);

        clienteRepository.save(cliente);

        String token = tokenService.generateToken(cliente);

        return ResponseEntity.ok(new ResponseDTO(
                cliente.getId(),
                cliente.getNome(),
                cliente.getEmail(),
                token
        ));
    }

    // GET PROFILE
    @GetMapping("/me")
    public ResponseEntity<?> getProfile(@RequestHeader("Authorization") String authHeader) {
        try {
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                return ResponseEntity.status(401).body("Token inválido");
            }

            String token = authHeader.replace("Bearer ", "");
            String email = tokenService.validateToken(token);

            Cliente cliente = clienteRepository.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

            Map<String, Object> dados = new HashMap<>();
            dados.put("id", cliente.getId());
            dados.put("nome", cliente.getNome());
            dados.put("email", cliente.getEmail());
            dados.put("cpf_cnpj", cliente.getCpf_cnpj());
            dados.put("logradouro", cliente.getLogradouro());
            dados.put("bairro", cliente.getBairro());
            dados.put("numero", cliente.getNumero());
            dados.put("complemento", cliente.getComplemento());
            dados.put("cidade", cliente.getCidade() != null ? cliente.getCidade().getNome() : null);

            return ResponseEntity.ok(dados);
        } catch (Exception e) {
            return ResponseEntity.status(401).body("Token expirado ou inválido");
        }
    }

    // UPDATE PROFILE (APENAS ENDEREÇO)
    @PutMapping("/me")
    public ResponseEntity<?> updateAddress(
            @RequestHeader("Authorization") String authHeader,
            @RequestBody Map<String, String> enderecoUpdates) {

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(401).body("Token inválido");
        }

        String token = authHeader.replace("Bearer ", "");
        String email = tokenService.validateToken(token);

        Cliente cliente = clienteRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

        // Atualiza apenas os campos do endereço
        if (enderecoUpdates.containsKey("logradouro")) cliente.setLogradouro(enderecoUpdates.get("logradouro"));
        if (enderecoUpdates.containsKey("bairro")) cliente.setBairro(enderecoUpdates.get("bairro"));
        if (enderecoUpdates.containsKey("numero")) cliente.setNumero(enderecoUpdates.get("numero"));
        if (enderecoUpdates.containsKey("complemento")) cliente.setComplemento(enderecoUpdates.get("complemento"));

        if (enderecoUpdates.containsKey("cidade")) {
            Cidade cidade = cidadeRepository.findByNome(enderecoUpdates.get("cidade"))
                    .orElseThrow(() -> new RuntimeException("Cidade não encontrada"));
            cliente.setCidade(cidade);
        }

        clienteRepository.save(cliente);

        return ResponseEntity.ok("Endereço atualizado com sucesso!");
    }
}
