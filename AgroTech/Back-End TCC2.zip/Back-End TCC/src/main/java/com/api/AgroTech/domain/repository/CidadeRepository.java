package com.api.AgroTech.domain.repository;

import com.api.AgroTech.domain.model.Cidade;
import com.api.AgroTech.domain.model.Estado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CidadeRepository extends JpaRepository<Cidade, Long> {

    // 🔹 Retorna uma cidade pelo nome e estado
    Optional<Cidade> findByNomeAndEstado(String nome, Estado estado);

    // 🔹 Retorna todas as cidades de um estado, ordenadas pelo nome
    List<Cidade> findByEstadoIdOrderByNome(Long estadoId);

    // 🔹 Retorna uma cidade pelo nome e sigla do estado (case insensitive)
    Optional<Cidade> findByNomeAndEstado_SiglaIgnoreCase(String nome, String siglaEstado);

    Optional<Object> findByNome(String cidade);
}
