create table estado (
    id int not null primary key auto_increment,
    sigla char(2),
    nome varchar(50)

) engine=InnoDB default charset=utf8;

create table cidade (
    id int not null primary key auto_increment,
    nome varchar(120),
    estado_id int not null

) engine=InnoDB default charset=utf8;

create table cliente (
    id int not null primary key auto_increment,
    nome varchar(100),
    cpf_cnpj varchar(100),
    logradouro varchar(100),
    numero varchar(10),
    bairro varchar(255),
    complemento varchar(120),
    email varchar(255) unique,
    senha varchar(255),
    cidade_id int not null

) engine=InnoDB default charset=utf8;

create table tipo_produto (
    id int not null primary key auto_increment,
    descricao varchar(255)

) engine=InnoDB default charset=utf8;

create table foto_produto (
    id int not null primary key auto_increment,
    produto_id int not null

) engine=InnoDB default charset=utf8;

create table produto (
    id int not null primary key auto_increment,
    nome_produto varchar(120),
    tipo_produto_id int not null,
    cliente_id int not null
    
) engine=InnoDB default charset=utf8;

create table anuncio (
    id int not null primary key auto_increment,
    titulo varchar(120),
    descricao varchar(100),
    produto_id int not null,
    preco decimal(12.2),
    status varchar(100)

) engine=InnoDB default charset=utf8;

alter table cliente add constraint fk_cliente_cidade foreign key(cidade_id) references cidade(id);

alter table cidade add constraint fk_cidade_estado foreign key(estado_id) references estado(id);

alter table produto add constraint fk_produto_cliente foreign key(cliente_id) references cliente(id);

alter table produto add constraint fk_produto_tipo_produto foreign key(tipo_produto_id) references tipo_produto(id);

alter table anuncio add constraint fk_anuncio_produto
foreign key(produto_id) references produto(id);

alter table foto_produto add constraint fk_foto_produto_produto
foreign key(produto_id) references produto(id);