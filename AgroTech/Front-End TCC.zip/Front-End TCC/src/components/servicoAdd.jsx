import { useState } from "react";
import axios from "axios";
import styles from "./servicoAdd.module.css";
import imgAdd from "../assets/addImg.png";

export default function ServicoAdd() {
  const [nome, setNome] = useState("");
  const [descricao, setDescricao] = useState("");
  const [preco, setPreco] = useState("");
  const [localizacao, setLocalizacao] = useState("");
  const [emailContato, setEmailContato] = useState("");
  const [telefoneContato, setTelefoneContato] = useState("");
  const [feedback, setFeedback] = useState("");

  const handleAddServico = async () => {
    if (!nome || !descricao || !preco || !localizacao) {
      setFeedback("Preencha todos os campos obrigatórios.");
      return;
    }

    try {
      await axios.post("http://localhost:8080/servicos", {
        nome,
        descricao,
        preco: parseFloat(preco),
        localizacao,
        emailContato,
        telefoneContato,
      });

      setFeedback("Serviço cadastrado com sucesso!");
      setNome("");
      setDescricao("");
      setPreco("");
      setLocalizacao("");
      setEmailContato("");
      setTelefoneContato("");
    } catch (err) {
      console.error(err);
      setFeedback("Erro ao cadastrar serviço.");
    }
  };

  return (
    <div className={styles.tudo}>
      <div className={styles.container}>
        {feedback && <div className={styles.feedback}>{feedback}</div>}

        <div className={styles.produto}>
          <div className={styles.img}>
            <img src={imgAdd} alt="Adicionar" />
          </div>
          <div className={styles.conteudo}>
            <input
              type="text"
              placeholder="Título do serviço"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
            />
            <input
              type="text"
              placeholder="Descrição"
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
            />
            <input
              type="text"
              placeholder="Localização"
              value={localizacao}
              onChange={(e) => setLocalizacao(e.target.value)}
            />
            <input
              type="text"
              placeholder="Preço do serviço"
              value={preco}
              onChange={(e) => setPreco(e.target.value)}
            />
          </div>
        </div>

        <div className={styles.contato}>
          <h1>Informações de Contato</h1>
          <input
            type="text"
            placeholder="E-mail"
            value={emailContato}
            onChange={(e) => setEmailContato(e.target.value)}
          />
          <input
            type="text"
            placeholder="Telefone"
            value={telefoneContato}
            onChange={(e) => setTelefoneContato(e.target.value)}
          />
        </div>

        <div className={styles.areaBotao}>
          <button className={styles.botaoAdicionar} onClick={handleAddServico}>
            Adicionar Serviço
          </button>
        </div>
      </div>
    </div>
  );
}
