import { useState, useEffect } from "react";
import axios from "axios";
import styles from "./servicoAdd.module.css";
import api from "../services/api"; // seu arquivo de api já configurado com baseURL e token

export default function ServicoAdd() {
  const [cliente, setCliente] = useState(null);

  const [nome, setNome] = useState("");
  const [descricao, setDescricao] = useState("");
  const [preco, setPreco] = useState("");
  const [localizacao, setLocalizacao] = useState("");
  const [emailContato, setEmailContato] = useState("");
  const [telefoneContato, setTelefoneContato] = useState("");

  const [arquivoFoto, setArquivoFoto] = useState(null);
  const [previewFoto, setPreviewFoto] = useState(null);
  const [feedback, setFeedback] = useState("");

  // 1️⃣ Buscar cliente logado e setar email
  useEffect(() => {
    const fetchCliente = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) return;

        const response = await api.get("/auth/me", {
          headers: { Authorization: `Bearer ${token}` },
        });

        setCliente(response.data);
        setEmailContato(response.data.email); // seta automaticamente o email
        setTelefoneContato(response.data.telefone || ""); // opcional: se tiver telefone no backend
      } catch (err) {
        console.error("Erro ao buscar cliente logado:", err);
      }
    };

    fetchCliente();
  }, []);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setArquivoFoto(file);

    if (previewFoto) URL.revokeObjectURL(previewFoto);
    setPreviewFoto(URL.createObjectURL(file));
  };

  const handleImageClick = () => {
    document.getElementById("fileInputServico").click();
  };

  const handleAddServico = async () => {
    if (!nome || !descricao || !preco || !localizacao) {
      setFeedback("Preencha todos os campos obrigatórios.");
      return;
    }

    try {
      // 1️⃣ Criar o serviço
      const servicoRes = await axios.post("http://localhost:8080/servicos", {
        nome,
        descricao,
        preco: parseFloat(preco),
        localizacao,
        emailContato,
        telefoneContato,
        cliente: { id: cliente.id }, // associa o cliente logado
      });

      const servicoCriado = servicoRes.data;
      console.log("Serviço criado:", servicoCriado);

      // 2️⃣ Enviar imagem
      if (arquivoFoto) {
        console.log(`Enviando foto para serviço ID: ${servicoCriado.id}`, arquivoFoto);
        const formData = new FormData();
        formData.append("file", arquivoFoto);

        await axios.post(
          `http://localhost:8080/fotos-servico/${servicoCriado.id}/upload`,
          formData,
          { headers: { "Content-Type": "multipart/form-data" } }
        );
      }

      // 3️⃣ Feedback e limpar
      setFeedback("Serviço cadastrado com sucesso!");
      setNome("");
      setDescricao("");
      setPreco("");
      setLocalizacao("");
      setArquivoFoto(null);
      if (previewFoto) URL.revokeObjectURL(previewFoto);
      setPreviewFoto(null);
    } catch (err) {
      console.error("Erro ao cadastrar serviço:", err);
      setFeedback("Erro ao cadastrar serviço.");
    }
  };

  if (!cliente) return <div>Carregando...</div>;

  return (
    <div className={styles.tudo}>
      <div className={styles.container}>
        {feedback && <div className={styles.feedback}>{feedback}</div>}

        <div className={styles.produto}>
          <div className={styles.img} onClick={handleImageClick}>
            {previewFoto ? (
              <img src={previewFoto} alt="Prévia" />
            ) : (
              <span>Clique para enviar imagem</span>
            )}

            <input
              type="file"
              id="fileInputServico"
              accept="image/*"
              onChange={handleFileChange}
              style={{ display: "none" }}
            />
          </div>

          <div className={styles.conteudo}>
            <input
              type="text"
              placeholder="Título do serviço"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
            />
            <input
              type="text"
              placeholder="Descrição"
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
            />
            <input
              type="text"
              placeholder="Localização"
              value={localizacao}
              onChange={(e) => setLocalizacao(e.target.value)}
            />
            <input
              type="text"
              placeholder="Preço"
              value={preco}
              onChange={(e) => setPreco(e.target.value)}
            />
          </div>
        </div>

        <div className={styles.contato}>
          <h1 className={styles.tituloContato}>Informações de Contato</h1>
          <div className={styles.coisa}>
            <div className={styles.conteE}>
              <h2>Email: </h2>
              <h1>{emailContato}</h1>
            </div>

            <div className={styles.conteT}>
              <h2>Telefone: </h2>
              <input
                className={styles.inputContato}
                placeholder="Telefone"
                value={telefoneContato}
                onChange={(e) => setTelefoneContato(e.target.value)}
              />
            </div>
          </div>
        </div>

        <div className={styles.areaBotao}>
          <button className={styles.botaoAdicionar} onClick={handleAddServico}>
            Adicionar Serviço
          </button>
        </div>
      </div>
    </div>
  );
}
