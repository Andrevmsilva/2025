import React from "react";
import styles from "./produto.module.css";

export default function Paginacao({ paginaAtual, totalPaginas, setPaginaAtual }) {
  if (totalPaginas <= 1) return null;

  // Determina o intervalo de páginas a exibir (máx. 5)
  let inicio = Math.max(1, paginaAtual - 2);
  let fim = Math.min(totalPaginas, inicio + 4);

  // Ajusta início se houver menos de 5 páginas no final
  inicio = Math.max(1, fim - 4);

  const paginas = [];
  for (let i = inicio; i <= fim; i++) {
    paginas.push(i);
  }

  return (
    <div className={styles.paginacao}>
      <button
        disabled={paginaAtual === 1}
        onClick={() => setPaginaAtual(paginaAtual - 1)}
      >
        ◀ Anterior
      </button>

      {paginas.map((num) => (
        <button
          key={num}
          className={paginaAtual === num ? styles.paginaAtiva : ""}
          onClick={() => setPaginaAtual(num)}
        >
          {num}
        </button>
      ))}

      <button
        disabled={paginaAtual === totalPaginas}
        onClick={() => setPaginaAtual(paginaAtual + 1)}
      >
        Próxima ▶
      </button>
    </div>
  );
}
