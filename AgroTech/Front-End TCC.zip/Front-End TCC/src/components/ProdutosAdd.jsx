import { useState } from "react";
import axios from "axios";

export default function ProdutosAdd() {
  const [nome, setNome] = useState("");
  const [descricao, setDescricao] = useState("");
  const [preco, setPreco] = useState("");
  const [estoque, setEstoque] = useState("");
  const [arquivoFotos, setArquivoFotos] = useState([]);
  const [previewFotos, setPreviewFotos] = useState([]);

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    setArquivoFotos(files);

    const previews = files.map((file) => URL.createObjectURL(file));
    setPreviewFotos(previews);
  };

  const handleAddProduto = async () => {
    try {
      // 1️⃣ Cria o produto
      const produtoRes = await axios.post("http://localhost:8080/produtos", {
        nome,
        descricao,
        preco: parseFloat(preco),
        estoque: parseInt(estoque),
      });

      const produtoCriado = produtoRes.data;
      console.log("Produto criado:", produtoCriado);

      // 2️⃣ Upload das fotos, se houver
      if (arquivoFotos.length > 0) {
        const formData = new FormData();
        arquivoFotos.forEach((file) => formData.append("files", file));

        await axios.post(
          `http://localhost:8080/fotos-produto/${produtoCriado.id}/upload-multiple`,
          formData,
          { headers: { "Content-Type": "multipart/form-data" } }
        );
      }

      alert("Produto e fotos cadastrados com sucesso!");
      setNome("");
      setDescricao("");
      setPreco("");
      setEstoque("");
      setArquivoFotos([]);
      setPreviewFotos([]);
    } catch (err) {
      console.error("Erro ao cadastrar produto:", err.response || err);
      alert("Erro ao cadastrar produto. Verifique o console para detalhes.");
    }
  };

  return (
    <div>
      <h1>Cadastrar Produto</h1>
      <input placeholder="Nome" value={nome} onChange={(e) => setNome(e.target.value)} />
      <input placeholder="Descrição" value={descricao} onChange={(e) => setDescricao(e.target.value)} />
      <input placeholder="Preço" type="number" value={preco} onChange={(e) => setPreco(e.target.value)} />
      <input placeholder="Estoque" type="number" value={estoque} onChange={(e) => setEstoque(e.target.value)} />
      <input type="file" multiple onChange={handleFileChange} />

      {/* Preview das fotos */}
      {previewFotos.length > 0 && (
        <div style={{ display: "flex", gap: "10px", marginTop: "10px" }}>
          {previewFotos.map((src, index) => (
            <img
              key={index}
              src={src}
              alt={`preview-${index}`}
              style={{ width: "100px", height: "100px", objectFit: "cover", border: "1px solid #ccc" }}
            />
          ))}
        </div>
      )}

      <button onClick={handleAddProduto} style={{ marginTop: "10px" }}>
        Cadastrar
      </button>
    </div>
  );
}
