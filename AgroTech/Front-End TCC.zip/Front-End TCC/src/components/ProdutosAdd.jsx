import { useState } from "react";
import axios from "axios";
import styles from "./ProdutosAdd.module.css";

export default function ProdutosAdd() {
  const [nome, setNome] = useState("");
  const [descricao, setDescricao] = useState("");
  const [preco, setPreco] = useState("");
  const [estoque, setEstoque] = useState("");

  const [localizacao, setLocalizacao] = useState("");
  const [emailContato, setEmailContato] = useState("");
  const [telefoneContato, setTelefoneContato] = useState("");
  const [tipoProdutoId, setTipoProdutoId] = useState("");

  const [arquivoFotos, setArquivoFotos] = useState([]);
  const [previewFotos, setPreviewFotos] = useState([]);

  const [feedbackMessage, setFeedbackMessage] = useState({ type: "", text: "" });

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    setArquivoFotos(files);

    previewFotos.forEach(URL.revokeObjectURL);
    const novaPreview = files.map((file) => URL.createObjectURL(file));
    setPreviewFotos(novaPreview);
  };

  const handleImageClick = () => {
    document.getElementById("fileInput").click();
  };

  const handlePrecoChange = (e) => {
    let value = e.target.value.replace(",", ".");
    let clean = value.replace(/[^0-9.]/g, "");

    const decimal = clean.indexOf(".");
    if (decimal !== -1) {
      clean =
        clean.substring(0, decimal + 1) +
        clean.substring(decimal + 1).replace(/\./g, "");

      const parts = clean.split(".");
      if (parts[1] && parts[1].length > 2) {
        clean = parts[0] + "." + parts[1].substring(0, 2);
      }
    }

    setPreco(clean);
  };

  const handleAddProduto = async () => {
    if (!nome || !descricao || !preco || !estoque || !localizacao || !tipoProdutoId) {
      setFeedbackMessage({ type: "error", text: "Preencha todos os campos obrigatórios." });
      return;
    }

    try {
      const produtoRes = await axios.post("http://localhost:8080/produtos", {
        nome,
        descricao,
        preco: parseFloat(preco),
        estoque: parseInt(estoque),
        localizacao,
        emailContato,
        telefoneContato,
        tipoProdutoId: parseInt(tipoProdutoId),
      });

      const produtoCriado = produtoRes.data;

      // Upload das fotos
      if (arquivoFotos.length > 0) {
        const formData = new FormData();
        arquivoFotos.forEach((file) => formData.append("files", file));

        await axios.post(
          `http://localhost:8080/fotos-produto/${produtoCriado.id}/upload-multiple`,
          formData,
          { headers: { "Content-Type": "multipart/form-data" } }
        );
      }

      setFeedbackMessage({ type: "success", text: "Produto cadastrado com sucesso!" });

      setNome("");
      setDescricao("");
      setPreco("");
      setEstoque("");
      setLocalizacao("");
      setEmailContato("");
      setTelefoneContato("");
      setTipoProdutoId("");
      setArquivoFotos([]);
      previewFotos.forEach(URL.revokeObjectURL);
      setPreviewFotos([]);

    } catch (err) {
      console.error(err);
      setFeedbackMessage({ type: "error", text: "Erro ao cadastrar produto." });
    }
  };

  return (
    <div className={styles.tudo}>
      <div className={styles.container}>

        {feedbackMessage.text && (
          <div
            className={`${styles.feedback} ${
              feedbackMessage.type === "success" ? styles.sucesso : styles.erro
            }`}
          >
            {feedbackMessage.text}
          </div>
        )}

        <div className={styles.produto}>

          {/* IMAGEM */}
          <div className={styles.img} onClick={handleImageClick}>
            {previewFotos.length > 0 ? (
              <img src={previewFotos[0]} alt="Prévia" />
            ) : (
              <span>Clique para enviar imagem</span>
            )}

            <input
              type="file"
              multiple
              accept="image/*"
              id="fileInput"
              onChange={handleFileChange}
              style={{ display: "none" }}
            />
          </div>

          {/* CAMPOS */}
          <div className={styles.conteudo}>
            <input
              className={styles.inputPadrao}
              placeholder="Nome"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
            />

            <input
              className={styles.inputPadrao}
              placeholder="Descrição"
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
            />

            <select
              className={styles.selectPadrao}
              value={tipoProdutoId}
              onChange={(e) => setTipoProdutoId(e.target.value)}
            >
              <option value="" disabled>Tipo</option>
              <option value="1">Geral</option>
              <option value="2">Maquinário</option>
              <option value="3">Peça</option>
            </select>

            <input
              className={styles.inputPadrao}
              placeholder="Estoque"
              type="number"
              value={estoque}
              onChange={(e) => setEstoque(e.target.value)}
            />

            <input
              className={styles.inputPadrao}
              placeholder="Localização"
              value={localizacao}
              onChange={(e) => setLocalizacao(e.target.value)}
            />

            <input
              className={styles.inputPadrao}
              placeholder="Preço (ex: 12.99)"
              value={preco}
              onChange={handlePrecoChange}
            />
          </div>
        </div>

        {/* CONTATO */}
        <h1 className={styles.tituloContato}>Informações de Contato</h1>

        <div className={styles.coisa}>
          <input
            className={styles.inputContato}
            placeholder="E-mail"
            value={emailContato}
            onChange={(e) => setEmailContato(e.target.value)}
          />

          <input
            className={styles.inputContato}
            placeholder="Telefone"
            value={telefoneContato}
            onChange={(e) => setTelefoneContato(e.target.value)}
          />
        </div>

        {/* BOTÃO */}
        <div className={styles.areaBotao}>
          <button className={styles.botaoAdicionar} onClick={handleAddProduto}>
            Cadastrar
          </button>
        </div>
      </div>
    </div>
  );
}
