import { useState } from "react";
import axios from "axios";
import styles from "./ProdutosAdd.module.css";

export default function ProdutosAdd() {
  const [nome, setNome] = useState("");
  const [descricao, setDescricao] = useState("");
  const [preco, setPreco] = useState("");
  const [estoque, setEstoque] = useState("");
  
  // NOVOS ESTADOS PARA CAMPOS FALTANDO
  const [localizacao, setLocalizacao] = useState(""); // Não aparece no seu HTML, mas é crucial
  const [emailContato, setEmailContato] = useState(""); 
  const [telefoneContato, setTelefoneContato] = useState(""); 
  const [tipoProdutoId, setTipoProdutoId] = useState(""); // Para o select

  const [arquivoFotos, setArquivoFotos] = useState([]);
  const [previewFotos, setPreviewFotos] = useState([]);

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    setArquivoFotos(files);

    const previews = files.map((file) => URL.createObjectURL(file));
    setPreviewFotos(previews);
  };

  // 🛑 CORREÇÃO A: Função para clicar no input hidden
  const handleImageClick = () => {
    document.getElementById('fileInput').click();
  };

  const handleAddProduto = async () => {
    // 🛑 VALIDAÇÃO MÍNIMA
    if (!nome || !descricao || !preco || !estoque || !localizacao) {
        alert("Preencha todos os campos obrigatórios (Nome, Descrição, Preço, Estoque e Localização).");
        return;
    }

    try {
      // 1️⃣ CRIA O PRODUTO: Incluindo os campos de contato
      const produtoRes = await axios.post("http://localhost:8080/produtos", {
        nome,
        descricao,
        preco: parseFloat(preco),
        estoque: parseInt(estoque),
        localizacao, // ENVIAR LOCALIZAÇÃO
        emailContato, // ENVIAR E-MAIL
        telefoneContato, // ENVIAR TELEFONE
        // tipoProdutoId: tipoProdutoId // Envio complexo, faremos depois
      });

      const produtoCriado = produtoRes.data;

      // 2️⃣ Upload das fotos
      if (arquivoFotos.length > 0) {
        const formData = new FormData();
        arquivoFotos.forEach((file) => formData.append("files", file));

        await axios.post(
          // Certifique-se que o controller no Spring aceita esse ID e path
          `http://localhost:8080/fotos-produto/${produtoCriado.id}/upload-multiple`, 
          formData,
          { headers: { "Content-Type": "multipart/form-data" } }
        );
      }

      alert("Produto e fotos cadastrados com sucesso!");
      // Limpeza dos estados
      setNome("");
      setDescricao("");
      setPreco("");
      setEstoque("");
      setLocalizacao("");
      setEmailContato("");
      setTelefoneContato("");
      setTipoProdutoId("");
      setArquivoFotos([]);
      setPreviewFotos([]);
    } catch (err) {
      alert("Erro ao cadastrar produto. Veja o console.");
      console.error("Erro completo:", err.response || err);
    }
  };

  return (
    <div className={styles.tudo}>
      <div className={styles.container}>

        <div className={styles.produto}>
          
          {/* BOX DA IMAGEM - Adicionamos o onClick para abrir a janela de arquivo */}
          <div className={styles.img} onClick={handleImageClick}> 
            {previewFotos.length > 0 ? (
              // 🛑 CORREÇÃO C: O input type file só deve mostrar UMA preview principal ou várias.
              <img src={previewFotos[0]} alt="Prévia da imagem principal" />
            ) : (
              <span className="imgtext">Clique para enviar imagem</span>
            )}

            <input 
              type="file" 
              multiple 
              onChange={handleFileChange}
              style={{ display: "none" }}
              id="fileInput" // ID usado na função handleImageClick
            />
          </div>

          {/* CONTEÚDO DO FORMULÁRIO */}
          <div className={styles.conteudo}>

            {/* Nome */}
            <div className={styles.titulo}>
              <input
                placeholder="Nome"
                value={nome}
                onChange={(e) => setNome(e.target.value)}
              />
            </div>

            {/* Descrição */}
            <div className={styles.desc}>
              <input
                placeholder="Descrição"
                value={descricao}
                onChange={(e) => setDescricao(e.target.value)}
              />
            </div>
            
            {/* Tipo (Select) - ATUALIZADO COM O ESTADO */}
            <select
              className={styles.select}
              value={tipoProdutoId}
              onChange={(e) => setTipoProdutoId(e.target.value)}
            >
              <option value="" disabled>
                Tipo
              </option>
              {/* ATENÇÃO: Os values devem ser IDs válidos na sua tabela TipoProduto do BD */}
              <option value="1">Geral</option> 
              <option value="2">Maquinário</option> 
              <option value="3">Peça</option> 
            </select> 
            
            {/* Localização / Estoque (ATUALIZADO PARA ESTOQUE) */}
            <div className={styles.endereco}> 
              <input
                placeholder="Estoque"
                type="number"
                value={estoque}
                onChange={(e) => setEstoque(e.target.value)}
              />
            </div>

            {/* Localização (Novo Campo) */}
            <div className={styles.endereco}> 
              <input
                placeholder="Localização (Cidade/Estado)"
                type="text"
                value={localizacao}
                onChange={(e) => setLocalizacao(e.target.value)}
              />
            </div>

            {/* Preço */}
            <div className={styles.preco}>
              <input
                placeholder="Preço"
                type="number"
                value={preco}
                onChange={(e) => setPreco(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* CAMPOS DE CONTATO - VINCULADOS AO ESTADO */}
        <div className={styles.contato}><h1>Adicione um E-mail e um Telefone para contato</h1></div>
        <div className={styles.coisa}>
          <div className={styles.conte}> 
            <input 
              type="text" 
              placeholder="E-mail" 
              value={emailContato}
              onChange={(e) => setEmailContato(e.target.value)}
            /> 
          </div> 
          <div className={styles.conte}> 
            <input 
              type="text" 
              placeholder="Telefone" 
              value={telefoneContato}
              onChange={(e) => setTelefoneContato(e.target.value)}
            /> 
          </div> 
        </div> 
        
        {/* BOTÃO ADICIONAR */}
        <div className={styles.areaBotao}>
          <button className={styles.botaoAdicionar} onClick={handleAddProduto}>
            Cadastrar
          </button>
        </div>

      </div>
    </div>
  );
}