import { useState, useEffect } from "react";
import axios from "axios";
import styles from "./ProdutosAdd.module.css";
import api from "../services/api";

export default function ProdutosAdd() {
  const [cliente, setCliente] = useState(null);

  const [nome, setNome] = useState("");
  const [descricao, setDescricao] = useState("");
  const [preco, setPreco] = useState("");
  const [estoque, setEstoque] = useState("");
  const [localizacao, setLocalizacao] = useState("");
  const [emailContato, setEmailContato] = useState("");
  const [telefoneContato, setTelefoneContato] = useState("");
  const [tipoProdutoId, setTipoProdutoId] = useState("");
  const [tiposProduto, setTiposProduto] = useState([]);
  const [loadingTipos, setLoadingTipos] = useState(true);
  const [arquivoFotos, setArquivoFotos] = useState([]);
  const [previewFotos, setPreviewFotos] = useState([]);
  const [feedbackMessage, setFeedbackMessage] = useState({ type: "", text: "" });

  // Buscar cliente logado
  useEffect(() => {
    const fetchCliente = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) return;

        const response = await api.get("/auth/me", {
          headers: { Authorization: `Bearer ${token}` },
        });

        setCliente(response.data);
        setEmailContato(response.data.email);
      } catch (err) {
        console.error("Erro ao buscar cliente logado:", err);
      }
    };

    fetchCliente();
  }, []);

  // Buscar tipos de produto
  useEffect(() => {
    const fetchTiposProduto = async () => {
      try {
        const response = await api.get("/tiposProduto");
        setTiposProduto(response.data);
      } catch (err) {
        console.error("Erro ao buscar tipos de produto:", err);
      } finally {
        setLoadingTipos(false);
      }
    };

    fetchTiposProduto();
  }, []);

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    setArquivoFotos(files);

    previewFotos.forEach(URL.revokeObjectURL);
    const novaPreview = files.map((file) => URL.createObjectURL(file));
    setPreviewFotos(novaPreview);
  };

  const handleImageClick = () => {
    document.getElementById("fileInput").click();
  };

  const handlePrecoChange = (e) => {
    let value = e.target.value.replace(",", ".");
    let clean = value.replace(/[^0-9.]/g, "");

    const decimal = clean.indexOf(".");
    if (decimal !== -1) {
      clean =
        clean.substring(0, decimal + 1) +
        clean.substring(decimal + 1).replace(/\./g, "");

      const parts = clean.split(".");
      if (parts[1] && parts[1].length > 2) {
        clean = parts[0] + "." + parts[1].substring(0, 2);
      }
    }

    setPreco(clean);
  };

  const handleAddProduto = async () => {
    if (!nome || !descricao || !preco || !estoque || !localizacao || !tipoProdutoId) {
      setFeedbackMessage({ type: "error", text: "Preencha todos os campos obrigatórios." });
      return;
    }

    try {
      const produtoRes = await axios.post("http://localhost:8080/produtos", {
        nome,
        descricao,
        preco: parseFloat(preco),
        estoque: parseInt(estoque),
        localizacao,
        emailContato,
        telefoneContato,
        tipoProduto: { id: parseInt(tipoProdutoId) },
        cliente: { id: cliente.id },
      });

      const produtoCriado = produtoRes.data;

      if (arquivoFotos.length > 0) {
        const formData = new FormData();
        arquivoFotos.forEach((file) => formData.append("files", file));

        await axios.post(
          `http://localhost:8080/fotos-produto/${produtoCriado.id}/upload-multiple`,
          formData,
          { headers: { "Content-Type": "multipart/form-data" } }
        );
      }

      setFeedbackMessage({ type: "success", text: "Produto cadastrado com sucesso!" });

      // Limpar campos
      setNome("");
      setDescricao("");
      setPreco("");
      setEstoque("");
      setLocalizacao("");
      setTelefoneContato("");
      setTipoProdutoId("");
      setArquivoFotos([]);
      previewFotos.forEach(URL.revokeObjectURL);
      setPreviewFotos([]);

    } catch (err) {
      console.error(err);
      setFeedbackMessage({ type: "error", text: "Erro ao cadastrar produto." });
    }
  };

  if (!cliente) return <div>Carregando...</div>;

  return (
    <div className={styles.tudo}>
      <div className={styles.container}>
        {feedbackMessage.text && (
          <div className={`${styles.feedback} ${feedbackMessage.type === "success" ? styles.sucesso : styles.erro}`}>
            {feedbackMessage.text}
          </div>
        )}

        <div className={styles.produto}>
          <div className={styles.img} onClick={handleImageClick}>
            {previewFotos.length > 0 ? (
              <img src={previewFotos[0]} alt="Prévia" />
            ) : (
              <span>Clique para enviar imagem</span>
            )}
            <input
              type="file"
              multiple
              accept="image/*"
              id="fileInput"
              onChange={handleFileChange}
              style={{ display: "none" }}
            />
          </div>

          <div className={styles.conteudo}>
            <input
              className={styles.inputTitulo}
              placeholder="Nome"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
            />

            <textarea
              className={styles.inputDesc}
              placeholder="Descrição"
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
            />

            <div style={{ display: "flex", gap: "10%" }}>
              {loadingTipos ? (
                <select className={styles.selectPadrao} disabled>
                  <option>Carregando tipos...</option>
                </select>
              ) : (
                <select
                  className={styles.selectPadrao}
                  value={tipoProdutoId}
                  onChange={(e) => setTipoProdutoId(e.target.value)}
                >
                  {!tipoProdutoId && <option value="" hidden>Tipo</option>}
                  {tiposProduto.map((tipo) => (
                    <option key={tipo.id} value={tipo.id}>{tipo.descricao}</option>
                  ))}
                </select>
              )}

              <input
                className={styles.inputEstoque}
                placeholder="Estoque"
                type="number"
                value={estoque}
                onChange={(e) => setEstoque(e.target.value)}
              />
            </div>

            <div style={{ display: "flex", gap: "10%" }}>
              <input
                className={styles.inputLoc}
                placeholder="Localização"
                value={localizacao}
                onChange={(e) => setLocalizacao(e.target.value)}
              />
              <input
                className={styles.inputPreco}
                placeholder="Preço (ex: 12.99)"
                value={preco}
                onChange={handlePrecoChange}
              />
            </div>
          </div>
        </div>

        <h1 className={styles.tituloContato}>Informações de Contato</h1>
        <div className={styles.coisa}>
          <div className={styles.conteE}>
            <h2>Email: </h2>
            <h1>{emailContato}</h1>
          </div>

          <div className={styles.conteT}>
            <h2>Telefone: </h2>
            <input
              className={styles.inputContato}
              placeholder="Telefone"
              value={telefoneContato}
              onChange={(e) => setTelefoneContato(e.target.value)}
            />
          </div>
        </div>

        <div className={styles.areaBotao}>
          <button className={styles.botaoAdicionar} onClick={handleAddProduto}>
            Cadastrar
          </button>
        </div>
      </div>
    </div>
  );
}
