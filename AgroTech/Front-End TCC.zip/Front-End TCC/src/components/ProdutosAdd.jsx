import { useState } from "react";
import axios from "axios";
import styles from "./ProdutosAdd.module.css";
import imgAdd from "../assets/addImg.png";

export default function ProdutosAdd() {
  const [nome, setNome] = useState("");
  const [descricao, setDescricao] = useState("");
  const [localizacao, setLocalizacao] = useState("");
  const [preco, setPreco] = useState("");
  const [emailContato, setEmailContato] = useState("");
  const [telefoneContato, setTelefoneContato] = useState("");
  const [fotos, setFotos] = useState([]);
  const [previewFotos, setPreviewFotos] = useState([]);

  // Captura arquivos e cria previews
  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    setFotos(files);

    const previews = files.map((file) => URL.createObjectURL(file));
    setPreviewFotos(previews);
  };

  const handleAddProduto = async () => {
    try {
      // 1️⃣ Criar produto
      const produto = {
        nome,
        descricao,
        localizacao,
        preco: parseFloat(preco),
        emailContato,
        telefoneContato
      };

      const produtoResponse = await axios.post(
        "http://localhost:8080/produtos",
        produto
      );

      const produtoId = produtoResponse.data.id;

      // 2️⃣ Upload das fotos (se houver)
      if (fotos.length > 0) {
        const formData = new FormData();
        formData.append("produtoId", produtoId);
        fotos.forEach((file) => formData.append("files", file)); // "files" plural conforme backend

        await axios.post(
          "http://localhost:8080/foto-produto/upload",
          formData,
          { headers: { "Content-Type": "multipart/form-data" } }
        );
      }

      alert("Produto cadastrado com sucesso!");

      // Limpar campos
      setNome("");
      setDescricao("");
      setLocalizacao("");
      setPreco("");
      setEmailContato("");
      setTelefoneContato("");
      setFotos([]);
      setPreviewFotos([]);
    } catch (error) {
      console.error("Erro ao cadastrar produto:", error);
      alert("Erro ao cadastrar produto!");
    }
  };

  return (
    <div className={styles.tudo}>
      <div className={styles.container}>
        <div className={styles.produto}>
          <div className={styles.img}>
            {previewFotos.length > 0 ? (
              previewFotos.map((src, index) => (
                <img key={index} src={src} alt={`Preview ${index}`} />
              ))
            ) : (
              <img src={imgAdd} alt="Adicionar imagem do produto" />
            )}
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={handleFileChange}
            />
          </div>

          <div className={styles.conteudo}>
            <input
              type="text"
              placeholder="Título do produto"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
            />
            <input
              type="text"
              placeholder="Descrição do produto"
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
            />
            <input
              type="text"
              placeholder="Localização"
              value={localizacao}
              onChange={(e) => setLocalizacao(e.target.value)}
            />
            <input
              type="text"
              placeholder="Preço"
              value={preco}
              onChange={(e) => setPreco(e.target.value)}
            />
          </div>
        </div>

        <div className={styles.contato}>
          <h1>Adicione um E-mail e um Telefone para contato</h1>
          <input
            type="text"
            placeholder="E-mail"
            value={emailContato}
            onChange={(e) => setEmailContato(e.target.value)}
          />
          <input
            type="text"
            placeholder="Telefone"
            value={telefoneContato}
            onChange={(e) => setTelefoneContato(e.target.value)}
          />
        </div>

        <button className={styles.botaoAdicionar} onClick={handleAddProduto}>
          Adicionar Produto
        </button>
      </div>
    </div>
  );
}
