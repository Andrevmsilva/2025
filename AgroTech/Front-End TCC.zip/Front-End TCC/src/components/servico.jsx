import { useEffect, useState } from "react";
import axios from "axios";
import styles from "./produto.module.css"; // Usando o mesmo CSS de Produto
import { Link } from "react-router-dom";

export default function Servicos() {
  const [servicos, setServicos] = useState([]);

  useEffect(() => {
    const fetchServicos = async () => {
      try {
        const res = await axios.get("http://localhost:8080/servicos");
        setServicos(res.data);
      } catch (err) {
        console.error("Erro ao carregar serviços:", err);
      }
    };

    fetchServicos();
  }, []);

  return (
    <div className={styles.tudo}>
      <div className={styles.container}>
        <div className={styles.gprod}>
          {servicos && servicos.length > 0 ? (
            servicos.map((s) => {
              const imagemSrc =
                s.fotos && s.fotos.length > 0
                  ? `http://localhost:8080/fotos-servico/file/${s.fotos[0].id}`
                  : "/sem-foto.png";

              return (
                <Link to={`/servicoVer/${s.id}`} key={s.id} className={styles.produtos}>
                  <div className={styles.img}>
                    <img src={imagemSrc} alt={s.nome || "Serviço"} />
                  </div>

                  <div className={styles.conteudo}>
                    <div className={styles.titulo}>
                      <h1>{s.nome || "Serviço sem nome"}</h1>
                    </div>
                    <div className={styles.desc}>
                      <h1>{s.descricao || "Sem descrição"}</h1>
                    </div>
                    <div className={styles.preco}>
                      <h1>R$ {s.preco?.toFixed(2) || "0.00"}</h1>
                    </div>
                    <div className={styles.endereco}>
                      <h1>{s.localizacao || "Não informado"}</h1>
                    </div>
                  </div>

                  <div className={styles.estoque}>
                    <h1>Email: {s.emailContato || "Não informado"}</h1>
                    <h1>Telefone: {s.telefoneContato || "Não informado"}</h1>
                  </div>
                </Link>
              );
            })
          ) : (
            <h2 style={{ color: "#fff", marginLeft: "5vh" }}>Nenhum serviço encontrado.</h2>
          )}
        </div>
      </div>
    </div>
  );
}
