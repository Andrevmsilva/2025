import { useEffect, useState } from "react";
import axios from "axios";
import styles from "./servico.module.css";
import { Link } from "react-router-dom";

export default function Servicos() {
  const [servicos, setServicos] = useState([]);

  useEffect(() => {
    const fetchServicos = async () => {
      try {
        const res = await axios.get("http://localhost:8080/servicos");
        setServicos(res.data);
      } catch (err) {
        console.error("Erro ao carregar serviços:", err);
      }
    };

    fetchServicos();
  }, []);

  return (
    <div className={styles.tudo}>
      <div className={styles.container}>
        <div className={styles.gprod}>
          {servicos && servicos.map((s) => (
            <Link to={`/servicoVer/${s.id}`} key={s.id} className={styles.produtos}>
              <div className={styles.conteudo}>
                <div className={styles.titulo}>
                  <h1>{s.nome}</h1>
                </div>
                <div className={styles.desc}>
                  <h1>{s.descricao}</h1>
                </div>
                <div className={styles.preco}>
                  <h1>R$ {s.preco?.toFixed(2) || "0.00"}</h1>
                </div>
                <div className={styles.endereco}>
                  <h1>{s.localizacao}</h1>
                </div>
                <div className={styles.contato}>
                  <h1>Email: {s.emailContato || "Não informado"}</h1>
                  <h1>Telefone: {s.telefoneContato || "Não informado"}</h1>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
