import styles from './Topo.module.css';
import logo from '../assets/logo.png';
import lupa from '../assets/procurar.png';
import perfil from '../assets/user.png';
import { Link, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";

export default function Topo() {

  const [texto, setTexto] = useState("");
  const [resultados, setResultados] = useState([]);
  const [mostrarDropdown, setMostrarDropdown] = useState(false);
  const navigate = useNavigate();

  const API_URL = "http://localhost:8080";

  // Buscar produtos + serviços da API conforme vai digitando
  useEffect(() => {
    const buscar = async () => {
      if (texto.trim() === "") {
        setResultados([]);
        return;
      }

      try {
        const [resProdutos, resServicos] = await Promise.all([
          axios.get(`${API_URL}/produtos`),
          axios.get(`${API_URL}/servicos`)
        ]);

        const listaProdutos = resProdutos.data.map(p => ({
          ...p,
          origem: "produto"
        }));

        const listaServicos = resServicos.data.map(s => ({
          ...s,
          origem: "servico"
        }));

        const tudo = [...listaProdutos, ...listaServicos];

        // Filtragem do texto
        const filtrado = tudo.filter(item => {
          const termo = texto.toLowerCase();
          return (
            item.nome?.toLowerCase().includes(termo) ||
            item.descricao?.toLowerCase().includes(termo) ||
            item.localizacao?.toLowerCase().includes(termo)
          );
        });

        setResultados(filtrado);
        setMostrarDropdown(true);

      } catch (err) {
        console.error("Erro ao buscar itens:", err);
      }
    };

    const timer = setTimeout(buscar, 250); // delay pra não spammar API
    return () => clearTimeout(timer);
  }, [texto]);


  // Quando clicar em um item, leva pro produto/serviço
  const abrirItem = (item) => {
    setMostrarDropdown(false);
    if (item.origem === "servico") {
      navigate(`/servicoVer/${item.id}`);
    } else {
      navigate(`/produtoVer/${item.id}`);
    }
  };


  return (
    <div className={styles.topo} style={{ position: "relative" }}>

      {/* LOGO */}
      <div className={styles.logo1}>
        <a href="http://localhost:5173/home">
          <img src={logo} alt="Logo do site" className={styles.logo} />
        </a>
      </div>

      {/* PESQUISA */}
      <div className={styles.pesquisa} style={{ position: "relative" }}>
        <input
          type="text"
          placeholder="Buscar"
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          onFocus={() => texto !== "" && setMostrarDropdown(true)}
        />

        <img
          src={lupa}
          alt="Ícone de busca"
          className={styles.iconeBusca}
        />

        {/* DROPDOWN DE RESULTADOS */}
        {mostrarDropdown && resultados.length > 0 && (
          <div
            className={styles.dropdown}
            style={{
              position: "absolute",
              top: "45px",
              left: 0,
              width: "100%",
              background: "white",
              borderRadius: "6px",
              boxShadow: "0 4px 10px rgba(0,0,0,0.2)",
              zIndex: 1000,
              maxHeight: "300px",
              overflowY: "auto",
              textShadow: "none"
            }}
          >
            {resultados.map((item) => {
              const endpoint = item.origem === "servico"
                ? "fotos-servico"
                : "fotos-produto";

              const img =
                item.fotos?.length > 0
                  ? `${API_URL}/${endpoint}/file/${item.fotos[0].id}`
                  : "/sem-foto.png";

              return (
                <div
                  key={`${item.origem}-${item.id}`}
                  onClick={() => abrirItem(item)}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    padding: "10px",
                    cursor: "pointer",
                    borderBottom: "1px solid #ddd",
                    textShadow: "none"
                  }}
                >
                  <img
                    src={img}
                    alt=""
                    style={{ width: "45px", height: "45px", borderRadius: "4px", objectFit: "cover", marginRight: "10px" }}
                  />
                  <div>
                    <div style={{ textShadow: "none"}}>{item.nome}</div>
                    <div style={{ fontSize: "0.8em", color: "#666", textShadow: "none" }}>
                      {item.origem === "servico" ? "Serviço" : "Produto"}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>

      {/* PERFIL */}
      <div className={styles.perfil}>
        <Link to="/">
          <img src={perfil} alt="icone de perfil" className={styles.iconePerfil} />
        </Link>
      </div>
    </div>
  );
}
