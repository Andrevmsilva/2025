import { useState, useEffect } from "react";
import styles from "./EditandoE.module.css";
import Button from 'react-bootstrap/Button';
import { useNavigate } from "react-router-dom";
import api from "../services/api";

export default function EditandoE() {
    const navigate = useNavigate();
    const [endereco, setEndereco] = useState({
        logradouro: "",
        bairro: "",
        numero: "",
        complemento: "",
        cidade: ""
    });

    // Busca dados do cliente
    useEffect(() => {
        const fetchEndereco = async () => {
            try {
                const token = localStorage.getItem("token");
                const response = await api.get("/auth/me", {
                    headers: { Authorization: `Bearer ${token}` }
                });

                const data = response.data;
                setEndereco({
                    logradouro: data.logradouro || "",
                    bairro: data.bairro || "",
                    numero: data.numero || "",
                    complemento: data.complemento || "",
                    cidade: data.cidade || ""
                });
            } catch (error) {
                console.error("Erro ao buscar dados:", error);
            }
        };

        fetchEndereco();
    }, []);

    // Atualiza campos do endereço
    const handleChange = (e) => {
        setEndereco({ ...endereco, [e.target.name]: e.target.value });
    };

    // Salva alterações
    const handleSave = async () => {
        try {
            const token = localStorage.getItem("token");
            await api.put("/auth/me", endereco, {
                headers: { Authorization: `Bearer ${token}` }
            });
            alert("Endereço atualizado com sucesso!");
            navigate("/home");
        } catch (error) {
            console.error("Erro ao salvar endereço:", error);
            alert("Falha ao atualizar endereço.");
        }
    };

    return (
        <div className={styles.tudo}>
            <div className={styles.container}>
                <div className={styles.conteudo}>
                    <div className={styles.endereco}>
                        <div className={styles.info}>
                            <div className={styles.titulo}><h1>Endereço</h1></div>
                            <input type="text" name="logradouro" placeholder="Logradouro" value={endereco.logradouro} onChange={handleChange} />
                            <input type="text" name="bairro" placeholder="Bairro" value={endereco.bairro} onChange={handleChange} />
                            <input type="text" name="numero" placeholder="Número" value={endereco.numero} onChange={handleChange} />
                            <input type="text" name="complemento" placeholder="Complemento" value={endereco.complemento} onChange={handleChange} />
                            <input type="text" name="cidade" placeholder="Cidade" value={endereco.cidade} onChange={handleChange} />
                        </div>
                        <Button className={styles.editar} onClick={handleSave}>Salvar</Button>
                    </div>
                </div>
            </div>
        </div>
    );
}
