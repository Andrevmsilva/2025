import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import Carousel from "react-bootstrap/Carousel";
import styles from "./ProdutosVer.module.css";

export default function ProdutosVer() {
    const { id } = useParams();
    const [produto, setProduto] = useState(null);
    const [fotos, setFotos] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const buscarProduto = async () => {
            try {
                const res = await axios.get(`http://localhost:8080/produtos/${id}`);
                setProduto(res.data);

                if (res.data.fotos && res.data.fotos.length > 0) {
                    const urls = res.data.fotos.map(
                        foto => `http://localhost:8080/fotos-produto/file/${foto.id}`
                    );
                    setFotos(urls);
                }

            } catch (err) {
                console.error("Erro ao carregar produto:", err);
            } finally {
                setLoading(false);
            }
        };

        buscarProduto();
    }, [id]);

    if (loading) {
        return <h1 style={{ color: "white", textAlign: "center", marginTop: "50px" }}>Carregando...</h1>;
    }

    if (!produto) {
        return <h1 style={{ color: "white", textAlign: "center", marginTop: "50px" }}>Produto não encontrado</h1>;
    }

    // Determinar valor legível para tipoProduto
    const tipoProdutoTexto = produto.tipoProduto
        ? produto.tipoProduto.descricao || "Tipo não informado"
        : "Tipo não informado";

    return (
        <div className={styles.tudo}>
            <div className={styles.container}>
                <div className={styles.produto}>

                    {/* CARROSSEL */}
                    <div className={styles.carro}>
                        <Carousel>
                            {fotos.length > 0 ? (
                                fotos.map((src, index) => (
                                    <Carousel.Item key={index}>
                                        <img
                                            className={styles.img1}
                                            src={src}
                                            alt={`Foto ${index + 1}`}
                                            onError={(e) =>
                                                e.currentTarget.src = "https://placehold.co/800x600?text=Sem+Foto"
                                            }
                                        />
                                    </Carousel.Item>
                                ))
                            ) : (
                                <Carousel.Item>
                                    <h2 style={{ textAlign: "center", padding: "60px" }}>
                                        Nenhuma foto enviada
                                    </h2>
                                </Carousel.Item>
                            )}
                        </Carousel>
                    </div>

                    {/* INFORMAÇÕES */}
                    <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>{produto.nome}</h1></div>

                        {/* Tipo do produto */}
                        <div className={styles.tipoProduto}>
                            <h2>Tipo: {tipoProdutoTexto}</h2>
                        </div>

                        <div className={styles.desc}><h1>{produto.descricao}</h1></div>
                        <div className={styles.endereco}><h1>{produto.localizacao}</h1></div>
                        <div className={styles.estoque}><h1>Estoque: {produto.estoque} unidades</h1></div>
                        <div className={styles.preco}><h1>R$ {produto.preco.toFixed(2)}</h1></div>

                        <div className={styles.tipoProduto}>
                            <h6>Tipo: {produto.tipoProduto ? produto.tipoProduto.descricao : "Não informado"}</h6>
                        </div>
                    </div>
                </div>

                {/* CONTATO */}
                <div className={styles.contato}>
                    <h1>Se houver interesse, entre em contato com o vendedor</h1>
                </div>

                <div className={styles.coisa}>
                    <div className={styles.conte}>
                        <h2>E-mail:</h2>
                        <h1>{produto.emailContato || "Não informado"}</h1>
                    </div>

                    <div className={styles.conte}>
                        <h2>Telefone:</h2>
                        <h1>{produto.telefoneContato || "Não informado"}</h1>
                    </div>
                </div>
            </div>
        </div>
    );
}
