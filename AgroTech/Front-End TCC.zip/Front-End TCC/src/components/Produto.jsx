import { useEffect, useState } from "react";
import axios from "axios";
import styles from "./produto.module.css";
import { Link } from "react-router-dom";

export default function Produto() {
  const [produtos, setProdutos] = useState([]);
  const [filtroPreco, setFiltroPreco] = useState([]);
  const [filtroCategoria, setFiltroCategoria] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:8080/produtos")
      .then((res) => setProdutos(res.data))
      .catch((err) => console.error("Erro ao carregar produtos:", err));
  }, []);

  // Função para filtrar produtos
  const produtosFiltrados = produtos.filter((p) => {
    // Filtra por preço
    const preco = p.preco || 0;
    let precoOk = filtroPreco.length === 0 || filtroPreco.some((range) => {
      if (range === "100-500") return preco >= 100 && preco <= 500;
      if (range === "500-1000") return preco > 500 && preco <= 1000;
      if (range === "1000-5000") return preco > 1000 && preco <= 5000;
      return false;
    });

    // Filtra por categoria
    const categoriaOk =
      filtroCategoria.length === 0 ||
      filtroCategoria.includes(p.categoria || "Todos");

    return precoOk && categoriaOk;
  });

  // Manipuladores de checkbox
  const handlePrecoChange = (e, range) => {
    if (e.target.checked) {
      setFiltroPreco([...filtroPreco, range]);
    } else {
      setFiltroPreco(filtroPreco.filter((r) => r !== range));
    }
  };

  const handleCategoriaChange = (e, categoria) => {
    if (e.target.checked) {
      setFiltroCategoria([...filtroCategoria, categoria]);
    } else {
      setFiltroCategoria(filtroCategoria.filter((c) => c !== categoria));
    }
  };

  return (
    <div className={styles.tudo}>
      <div className={styles.container}>

        {/* FILTROS */}
        <div className={styles.filtro}>
          <div className={styles.fpreco}>
            <h1>Preço</h1>
            <div className={styles.marcar}>
              <div className={styles.primeiro}>
                <h2>R$100,00 até R$500,00</h2>
                <input type="checkbox" onChange={(e) => handlePrecoChange(e, "100-500")}/>
              </div>
              <div className={styles.segundo}>
                <h2>R$500,00 até R$1000,00</h2>
                <input type="checkbox" onChange={(e) => handlePrecoChange(e, "500-1000")}/>
              </div>
              <div className={styles.terceiro}>
                <h2>R$1000,00 até R$5000,00</h2>
                <input type="checkbox" onChange={(e) => handlePrecoChange(e, "1000-5000")}/>
              </div>
            </div>
          </div>

          <div className={styles.fcategoria}>
            <h1>Categorias</h1>
            <div className={styles.marcar}>
              <div className={styles.cprimeiro}>
                <h2>Todos os Produtos</h2>
                <input type="checkbox" onChange={(e) => handleCategoriaChange(e, "Todos")}/>
              </div>
              <div className={styles.csegundo}>
                <h2>Maquinários</h2>
                <input type="checkbox" onChange={(e) => handleCategoriaChange(e, "Maquinários")}/>
              </div>
              <div className={styles.cterceiro}>
                <h2>Peças</h2>
                <input type="checkbox" onChange={(e) => handleCategoriaChange(e, "Peças")}/>
              </div>
              <div className={styles.cquarto}>
                <h2>Serviços</h2>
                <input type="checkbox" onChange={(e) => handleCategoriaChange(e, "Serviços")}/>
              </div>
            </div>
          </div>
        </div>

        {/* PRODUTOS */}
        <div className={styles.gprod}>
          {produtosFiltrados.length > 0 ? (
            produtosFiltrados.map((p) => { 
              const precoFormatado = p.preco != null ? p.preco.toFixed(2) : "0.00";
              const imagemSrc =
                p.fotos && p.fotos.length > 0
                  ? `http://localhost:8080/fotos-produto/file/${p.fotos[0].id}`
                  : "/sem-foto.png";
              const estoque = p.estoque != null ? p.estoque : "Indisponível";
              const localizacao = p.localizacao || "Não informado";

              return (
                <Link to={`/produtoVer/${p.id}`} key={p.id} className={styles.produtos}>
                  <div className={styles.img}>
                    <img src={imagemSrc} alt={p.nome || "Produto"} />
                  </div>

                  <div className={styles.conteudo}>
                    <div className={styles.titulo}>
                      <h1>{p.nome || "Produto sem nome"}</h1>
                    </div>
                    <div className={styles.desc}>
                      <h1>{p.descricao || "Sem descrição"}</h1>
                    </div>
                    <div className={styles.preco}>
                      <h1>R$ {precoFormatado}</h1>
                    </div>
                    <div className={styles.endereco}>
                      <h1>{localizacao}</h1>
                    </div>
                  </div>

                  <div className={styles.estoque}>
                    <h1>Estoque: {estoque}</h1>
                  </div>
                </Link>
              );
            })
          ) : (
            <h2 style={{ color: "#fff", marginLeft: "5vh" }}>Nenhum produto encontrado.</h2>
          )}
        </div>

      </div>
    </div>
  );
}
