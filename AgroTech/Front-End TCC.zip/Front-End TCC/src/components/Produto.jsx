import { useEffect, useState } from "react";
import axios from "axios";
import styles from "./produto.module.css";
import { Link } from "react-router-dom";

export default function Produto() {
  const [produtos, setProdutos] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:8080/produtos")
      .then((res) => setProdutos(res.data))
      .catch((err) => console.error("Erro ao carregar produtos:", err));
  }, []);

  return (
    <div className={styles.tudo}>
      <div className={styles.container}>
        <div className={styles.gprod}>
          {/* CORREÇÃO: Adicionamos 'produtos && Array.isArray(produtos) &&' 
            Isso garante que .map() só será chamado se 'produtos' for um array. 
          */}
          {produtos && Array.isArray(produtos) && produtos.map((p) => { 
            const precoFormatado = p.preco != null ? p.preco.toFixed(2) : "0.00";

            const imagemSrc =
              p.fotos && p.fotos.length > 0
                ? `http://localhost:8080/fotos-produto/file/${p.fotos[0].id}`
                : "/sem-foto.png";

            const estoque = p.estoque != null ? p.estoque : "Indisponível";
            const localizacao = p.localizacao || "Não informado";

            return (
              <Link to={`/produtoVer/${p.id}`} key={p.id} className={styles.produtos}>
                <div className={styles.img}>
                  <img src={imagemSrc} alt={p.nome || "Produto"} />
                </div>

                <div className={styles.conteudo}>
                  <div className={styles.titulo}>
                    <h1>{p.nome || "Produto sem nome"}</h1>
                  </div>
                  <div className={styles.desc}>
                    <h1>{p.descricao || "Sem descrição"}</h1>
                  </div>
                  <div className={styles.preco}>
                    <h1>R$ {precoFormatado}</h1>
                  </div>
                  <div className={styles.endereco}>
                    <h1>{localizacao}</h1>
                  </div>
                </div>

                <div className={styles.estoque}>
                  <h1>Estoque: {estoque}</h1>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}