import { useEffect, useState } from "react";
import axios from "axios";
import styles from "./produto.module.css";
import { Link, useSearchParams } from "react-router-dom";
import Paginacao from "./Paginacao";

export default function Produto() {
  const [todosItens, setTodosItens] = useState([]);
  const [filtroPreco, setFiltroPreco] = useState([]);
  const [paginaAtual, setPaginaAtual] = useState(1);
  const itensPorPagina = 5; // definir quantidade de itens por página

  const [searchParams] = useSearchParams();
  const [filtroCategoria, setFiltroCategoria] = useState(() => {
    const categoriaUrl = searchParams.get("categoria");
    return categoriaUrl ? [categoriaUrl] : [];
  });

  const API_URL = "http://localhost:8080";

  useEffect(() => {
    const carregar = async () => {
      try {
        const [resProd, resServ] = await Promise.all([
          axios.get(`${API_URL}/produtos`),
          axios.get(`${API_URL}/servicos`)
        ]);

        const produtos = resProd.data.map(p => ({ ...p, origem: "produto" }));
        const servicos = resServ.data.map(s => ({ ...s, origem: "servico" }));

        setTodosItens([...produtos, ...servicos]);
      } catch (e) {
        console.error(e);
      }
    };
    carregar();
  }, []);

  // FILTRO
  const itensFiltrados = todosItens.filter((item) => {
    const preco = item.preco || 0;

    const precoOk =
      filtroPreco.length === 0 ||
      filtroPreco.some((range) => {
        if (range === "100-500") return preco >= 100 && preco <= 500;
        if (range === "500-1000") return preco > 500 && preco <= 1000;
        if (range === "1000-5000") return preco > 1000 && preco <= 5000;
        return false;
      });

    let categoriaItem = item.origem === "servico"
      ? "Serviços"
      : item.tipoProduto?.descricao || item.categoria || "";

    const categoriaOk =
      filtroCategoria.length === 0 ||
      filtroCategoria.includes("Todos") ||
      filtroCategoria.includes(categoriaItem);

    return precoOk && categoriaOk;
  });

  // RESETAR PARA PÁGINA 1 SEMPRE QUE MUDAR FILTROS
  useEffect(() => {
    setPaginaAtual(1);
  }, [filtroPreco, filtroCategoria]);

  // PAGINAÇÃO
  const totalPaginas = Math.ceil(itensFiltrados.length / itensPorPagina);
  const inicio = (paginaAtual - 1) * itensPorPagina;
  const fim = inicio + itensPorPagina;
  const itensPagina = itensFiltrados.slice(inicio, fim);

  // HANDLERS
  const handlePrecoChange = (e, range) => {
    if (e.target.checked) {
      setFiltroPreco([...filtroPreco, range]);
    } else {
      setFiltroPreco(filtroPreco.filter((r) => r !== range));
    }
  };

  const handleCategoriaChange = (e, categoria) => {
    if (e.target.checked) {
      if (categoria === "Todos") {
        setFiltroCategoria(["Todos"]);
      } else {
        const limpar = filtroCategoria.filter((c) => c !== "Todos");
        setFiltroCategoria([...limpar, categoria]);
      }
    } else {
      setFiltroCategoria(filtroCategoria.filter((c) => c !== categoria));
    }
  };

  const isCategoryChecked = (categoria) => {
    if (filtroCategoria.includes("Todos")) return categoria === "Todos";
    return filtroCategoria.includes(categoria);
  };

  return (
    <div className={styles.tela}>
      <div className={styles.container}>

        {/* SIDEBAR */}
        <aside className={styles.sidebar}>
          {/* PREÇOS */}
          <div className={styles.boxFiltro}>
            <h3>Preço</h3>
            <label className={styles.linha}>
              <span>R$100 até R$500</span>
              <input 
                type="checkbox"
                checked={filtroPreco.includes("100-500")}
                onChange={(e) => handlePrecoChange(e, "100-500")}
              />
            </label>
            <label className={styles.linha}>
              <span>R$500 até R$1000</span>
              <input 
                type="checkbox"
                checked={filtroPreco.includes("500-1000")}
                onChange={(e) => handlePrecoChange(e, "500-1000")}
              />
            </label>
            <label className={styles.linha}>
              <span>R$1000 até R$5000</span>
              <input 
                type="checkbox"
                checked={filtroPreco.includes("1000-5000")}
                onChange={(e) => handlePrecoChange(e, "1000-5000")}
              />
            </label>
          </div>

          {/* CATEGORIAS */}
          <div className={styles.boxFiltro}>
            <h3>Categorias</h3>
            <label className={styles.linha}>
              <span>Todos os Produtos</span>
              <input 
                type="checkbox"
                checked={isCategoryChecked("Todos")}
                onChange={(e) => handleCategoriaChange(e, "Todos")}
              />
            </label>
            <label className={styles.linha}>
              <span>Maquinários</span>
              <input 
                type="checkbox"
                checked={isCategoryChecked("Maquinário")}
                onChange={(e) => handleCategoriaChange(e, "Maquinário")}
              />
            </label>
            <label className={styles.linha}>
              <span>Peças</span>
              <input 
                type="checkbox"
                checked={isCategoryChecked("Peça")}
                onChange={(e) => handleCategoriaChange(e, "Peça")}
              />
            </label>
            <label className={styles.linha}>
              <span>Serviços</span>
              <input 
                type="checkbox"
                checked={isCategoryChecked("Serviços")}
                onChange={(e) => handleCategoriaChange(e, "Serviços")}
              />
            </label>
          </div>
        </aside>

        {/* LISTA */}
        <main className={styles.lista}>
          {itensPagina.length === 0 && (
            <h2 className={styles.nada}>Nenhum item encontrado.</h2>
          )}

          {itensPagina.map((item) => {
            const isService = item.origem === "servico";
            const rota = isService ? "servicoVer" : "produtoVer";
            const endpoint = isService ? "fotos-servico" : "fotos-produto";

            const img =
              item.fotos?.length > 0
                ? `${API_URL}/${endpoint}/file/${item.fotos[0].id}`
                : "/sem-foto.png";

            return (
              <Link
                to={`/${rota}/${item.id}`}
                key={`${item.origem}-${item.id}`}
                className={styles.card}
              >
                <img src={img} alt="" className={styles.img} />

                <div className={styles.info}>
                  <h1>{item.nome}</h1>
                  <p className={styles.desc}>
                    {item.descricao?.slice(0, 60) || "Sem descrição"}...
                  </p>
                  <h2 className={styles.preco}>
                    R$ {(item.preco || 0).toFixed(2)}
                  </h2>
                  <p className={styles.local}>{item.localizacao || "Local não informado"}</p>
                </div>
              </Link>
            );
          })}

          {/* PAGINAÇÃO */}
          <Paginacao
            paginaAtual={paginaAtual}
            totalPaginas={totalPaginas}
            setPaginaAtual={setPaginaAtual}
          />
        </main>

      </div>
    </div>
  );
}
