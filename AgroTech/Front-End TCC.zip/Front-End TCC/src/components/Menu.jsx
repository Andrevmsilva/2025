import styles from "./Menu.module.css";
import { useState } from "react";
import { Link } from "react-router-dom";

export default function Menu() {
  const [openVender, setOpenVender] = useState(false);

  const toggleDropdownVender = () => {
    setOpenVender(!openVender);
  };

  return (
    <div className={styles.container}>
      <div className={styles.conteudo}>

        <Link to="/home" className={styles.c3}>
          <div>Home</div>
        </Link>
        
        {/* CATEGORIAS */}
        <Link to="/Produtos" className={styles.c3}>
          <div>Produtos</div>
        </Link>

        {/* VENDER */}
        <div className={styles.c2} onClick={toggleDropdownVender}>
          Vender
          {openVender && (
            <div className={styles.dropc2}>
              <Link to="/produtoAdd"><div>Produto</div></Link>
              <Link to="/servicosAdd"><div>Serviço</div></Link>
            </div>
          )}
        </div>

        {/* CONTA */}
        <Link to="/conta" className={styles.c4}>
          <div>Conta</div>
        </Link>

      </div>
    </div>
  );
}