import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import Carousel from "react-bootstrap/Carousel";
import styles from "./servicoVer.module.css";

export default function ServicoVer() {
    const { id } = useParams();
    const [servico, setServico] = useState(null);
    const [fotos, setFotos] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const buscarServico = async () => {
            try {
                const res = await axios.get(`http://localhost:8080/servicos/${id}`);
                setServico(res.data);

                if (res.data.fotos && res.data.fotos.length > 0) {
                    const urls = res.data.fotos.map(
                        foto => `http://localhost:8080/fotos-servico/file/${foto.id}`
                    );
                    setFotos(urls);
                }
            } catch (err) {
                console.error("Erro ao carregar serviço:", err);
            } finally {
                setLoading(false);
            }
        };

        buscarServico();
    }, [id]);

    if (loading) {
        return <h1 style={{ color: "white", textAlign: "center", marginTop: "50px" }}>Carregando...</h1>;
    }

    if (!servico) {
        return <h1 style={{ color: "white", textAlign: "center", marginTop: "50px" }}>Serviço não encontrado</h1>;
    }

    return (
        <div className={styles.tudo}>
            <div className={styles.container}>
                <div className={styles.produto}>
                    {/* CARROSSEL */}
                    <div className={styles.carro}>
                        <Carousel>
                            {fotos.length > 0 ? (
                                fotos.map((src, index) => (
                                    <Carousel.Item key={index}>
                                        <img
                                            className={styles.img1}
                                            src={src}
                                            alt={`Foto ${index + 1}`}
                                            onError={(e) =>
                                                e.currentTarget.src = "https://placehold.co/800x600?text=Sem+Foto"
                                            }
                                        />
                                    </Carousel.Item>
                                ))
                            ) : (
                                <Carousel.Item>
                                    <h2 style={{ textAlign: "center", padding: "60px" }}>
                                        Nenhuma foto enviada
                                    </h2>
                                </Carousel.Item>
                            )}
                        </Carousel>
                    </div>

                    {/* INFORMAÇÕES */}
                    <div className={styles.conteudo}>
                        <div className={styles.titulo}><h1>{servico.nome}</h1></div>
                        <div className={styles.desc}><h1>{servico.descricao}</h1></div>
                        <div className={styles.endereco}><h1>{servico.localizacao}</h1></div>
                        <div className={styles.preco}><h1>R$ {servico.preco.toFixed(2)}</h1></div>
                    </div>
                </div>

                {/* CONTATO */}
                <div className={styles.contato}>
                    <h1>Se houver interesse, entre em contato com o vendedor</h1>
                </div>

                <div className={styles.coisa}>
                    <div className={styles.conte}>
                        <h2>E-mail:</h2>
                        <h1>{servico.emailContato || "Não informado"}</h1>
                    </div>

                    <div className={styles.conte}>
                        <h2>Telefone:</h2>
                        <h1>{servico.telefoneContato || "Não informado"}</h1>
                    </div>
                </div>
            </div>
        </div>
    );
}
