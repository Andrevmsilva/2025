import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
// import styles from "./Cards.module.css"; 
// Você deve manter seu CSS Module localmente. Aqui usarei styles inline para demonstração.

import { Link } from "react-router-dom"; 

// Placeholders para o exemplo funcionar sem arquivos locais
const servicosImg = "https://placehold.co/300x200/3d7e60/ffffff?text=Servicos";
const maquinarioImg = "https://placehold.co/300x200/3d7e60/ffffff?text=Maquinario";
const pecasImg = "https://placehold.co/300x200/3d7e60/ffffff?text=Pecas";
const produtosImg = "https://placehold.co/300x200/3d7e60/ffffff?text=Geral";

export default function Cards() {
  // Estilo inline básico para simular seu CSS Module no preview
  const styles = {
      tudo: { display: 'flex', flexWrap: 'wrap', gap: '20px', justifyContent: 'center', padding: '20px', backgroundColor: '#f0f0f0' },
      cubao: { width: '18rem', boxShadow: '0 4px 8px rgba(0,0,0,0.1)', borderRadius: '10px', overflow: 'hidden' },
      titulo: { backgroundColor: '#3d7e60', color: 'white', padding: '10px', textAlign: 'center', margin: 0, fontSize: '1.25rem', fontWeight: 'bold' },
      imgpai: { height: '200px', overflow: 'hidden' },
      img: { width: '100%', height: '100%', objectFit: 'cover' },
      descricao: { padding: '15px', color: '#555', minHeight: '80px' },
      sla: { display: 'flex', justifyContent: 'center', paddingBottom: '15px' },
      botao: { backgroundColor: '#3d7e60', border: 'none', padding: '10px 20px', color: 'white', borderRadius: '5px', cursor: 'pointer' }
  };

  return (
    <div style={styles.tudo}>

      {/* CARD SERVIÇOS */}
      <Card style={styles.cubao}>
        <div style={styles.titulo}>Serviços</div>
          <Card.Body>
            <div style={styles.imgpai}>
                <Card.Img style={styles.img} src={servicosImg}/>
            </div>
            <Card.Text style={styles.descricao}>Compra e venda de serviços</Card.Text>
            <div style={styles.sla}>
            {/* LINK para /produtos com filtro 'Serviços' */}
            <Link to="/produtos?categoria=Serviços">
              <Button style={styles.botao}>Buscar</Button>
            </Link>
            </div>
          </Card.Body>
      </Card>

      {/* CARD MAQUINÁRIOS */}
      <Card style={styles.cubao}>
        <div style={styles.titulo}>Maquinários</div>
          <Card.Body>
            <div style={styles.imgpai}>
                <Card.Img style={styles.img} src={maquinarioImg}/>
            </div>
            <Card.Text style={styles.descricao}>Compra e venda de maquinários</Card.Text>
            <div style={styles.sla}>
            {/* LINK para /produtos com filtro 'Maquinário' */}
            <Link to="/produtos?categoria=Maquinário">
              <Button style={styles.botao}>Buscar</Button>
            </Link>
            </div>
          </Card.Body>
      </Card>

      {/* CARD PEÇAS */}
      <Card style={styles.cubao}>
        <div style={styles.titulo}>Peças</div>
          <Card.Body>
            <div style={styles.imgpai}>
                <Card.Img style={styles.img} src={pecasImg}/>
            </div>
            <Card.Text style={styles.descricao}>Compra e venda de peças</Card.Text>
            <div style={styles.sla}>
            {/* LINK para /produtos com filtro 'Peça' */}
            <Link to="/produtos?categoria=Peça">
              <Button style={styles.botao}>Buscar</Button>
            </Link>
            </div>
          </Card.Body>
      </Card>

      {/* CARD GERAL */}
      <Card style={styles.cubao}>
        <div style={styles.titulo}>Geral</div>
          <Card.Body>
            <div style={styles.imgpai}>
                <Card.Img style={styles.img} src={produtosImg}/>
            </div>
            <Card.Text style={styles.descricao}>Compra e venda de produtos</Card.Text>
            <div style={styles.sla}>
            {/* LINK para /produtos com filtro 'Geral' */}
            <Link to="/produtos?categoria=Geral">
              <Button style={styles.botao}>Buscar</Button>
            </Link>
            </div>
          </Card.Body>
      </Card>
    </div>
  );
}