import Topo from '../../components/Topo'
import Menu from '../../components/Menu'
import Maquinas from '../../components/Maquinas'

export default function Produtos() {

    return (
      <div className="App">
        <div><Topo/></div>
        <div><Menu/></div>
        <div><Maquinas/></div>
      </div>
    );
  }