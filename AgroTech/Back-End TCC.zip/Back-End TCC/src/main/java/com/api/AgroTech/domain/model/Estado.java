package com.api.AgroTech.domain.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity

public class Estado {
    @Id
    @EqualsAndHashCode.Include
    private Long id; // id será o código IBGE


    private String nome;

    @Column(length = 2)
    private String sigla;
}