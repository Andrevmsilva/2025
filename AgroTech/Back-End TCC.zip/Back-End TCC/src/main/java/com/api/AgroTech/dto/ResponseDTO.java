package com.api.AgroTech.dto;



public record ResponseDTO(
        Long id,
        String name,
        String email,
        String token
) {}