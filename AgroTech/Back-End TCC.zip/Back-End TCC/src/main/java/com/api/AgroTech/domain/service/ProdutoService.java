package com.api.AgroTech.domain.service;

import com.api.AgroTech.domain.exception.EntidadeEmUsoException;
import com.api.AgroTech.domain.exception.EntidadeNaoEncontradaException;
import com.api.AgroTech.domain.model.Anuncio;
import com.api.AgroTech.domain.model.Produto;
import com.api.AgroTech.domain.repository.AnuncioRepository;
import com.api.AgroTech.domain.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

@Service
public class ProdutoService {
    @Autowired
    private ProdutoRepository produtoRepository;

    public Produto salvar(Produto produto) { return produtoRepository.save(produto); }

    public void excluir(Long id) {
        try {
            produtoRepository.deleteById(id);
        }
        catch (DataIntegrityViolationException e) {
            throw new EntidadeEmUsoException(String.format("Produto ou código %d não pode ser removido, pois está em uso.", id));
        }
        catch (EmptyResultDataAccessException e) {
            throw new EntidadeNaoEncontradaException(String.format("Não existe cadastro de produto com código %d", id));
        }
    }
}
