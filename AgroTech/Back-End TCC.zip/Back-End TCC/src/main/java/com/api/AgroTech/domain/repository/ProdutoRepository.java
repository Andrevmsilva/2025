package com.api.AgroTech.domain.repository;

import com.api.AgroTech.domain.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {
}
