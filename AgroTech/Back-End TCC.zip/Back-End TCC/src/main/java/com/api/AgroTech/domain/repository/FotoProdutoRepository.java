package com.api.AgroTech.domain.repository;

import com.api.AgroTech.domain.model.FotoProduto;
import com.api.AgroTech.domain.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface FotoProdutoRepository extends JpaRepository<FotoProduto, Long> {
    Optional<FotoProduto> findByNomeArquivo(String nomeArquivo);

    List<FotoProduto> findByProduto(Produto produto);
}

