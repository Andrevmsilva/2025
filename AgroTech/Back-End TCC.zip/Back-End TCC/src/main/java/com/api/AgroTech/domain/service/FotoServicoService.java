package com.api.AgroTech.domain.service;

import com.api.AgroTech.domain.exception.EntidadeNaoEncontradaException;
import com.api.AgroTech.domain.model.FotoServico;
import com.api.AgroTech.domain.model.Servico;
import com.api.AgroTech.domain.repository.FotoServicoRepository;
import com.api.AgroTech.domain.repository.ServicoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class FotoServicoService {

    private final FotoServicoRepository fotoServicoRepository;
    private final ServicoRepository servicoRepository;

    public FotoServicoService(FotoServicoRepository fotoServicoRepository,
                              ServicoRepository servicoRepository) {
        this.fotoServicoRepository = fotoServicoRepository;
        this.servicoRepository = servicoRepository;
    }

    @Transactional
    public void salvarFotos(Long servicoId, List<MultipartFile> files) throws IOException {
        Servico servico = servicoRepository.findById(servicoId)
                .orElseThrow(() -> new EntidadeNaoEncontradaException(
                        "Serviço não encontrado com ID: " + servicoId));

        for (MultipartFile file : files) {
            FotoServico foto = new FotoServico();
            foto.setServico(servico);
            foto.setConteudo(file.getBytes());
            foto.setNomeArquivo(file.getOriginalFilename());
            foto.setTipoConteudo(file.getContentType());
            foto.setDataUpload(LocalDateTime.now());

            fotoServicoRepository.save(foto);
        }
    }

    public Optional<FotoServico> buscarPorId(Long fotoId) {
        return fotoServicoRepository.findById(fotoId);
    }

    public Optional<FotoServico> buscarPorNome(String nomeArquivo) {
        return fotoServicoRepository.findByNomeArquivo(nomeArquivo);
    }

    public List<FotoServico> listarFotosPorServico(Long servicoId) {
        Servico servico = servicoRepository.findById(servicoId)
                .orElseThrow(() -> new EntidadeNaoEncontradaException(
                        "Serviço não encontrado com ID: " + servicoId));
        return fotoServicoRepository.findByServico(servico);
    }

    @Transactional
    public void excluir(Long fotoId) {
        FotoServico foto = fotoServicoRepository.findById(fotoId)
                .orElseThrow(() -> new EntidadeNaoEncontradaException(
                        "Foto não encontrada com ID: " + fotoId));
        fotoServicoRepository.delete(foto);
    }
}
