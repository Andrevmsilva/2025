package com.api.AgroTech.domain.service;

import com.api.AgroTech.domain.exception.EntidadeEmUsoException;
import com.api.AgroTech.domain.exception.EntidadeNaoEncontradaException;
import com.api.AgroTech.domain.model.Anuncio;
import com.api.AgroTech.domain.repository.AnuncioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

@Service
public class AnuncioService {
    @Autowired
    private AnuncioRepository anuncioRepository;

    public Anuncio salvar(Anuncio anuncio) { return anuncioRepository.save(anuncio); }

    public void excluir(Long id) {
        try {
            anuncioRepository.deleteById(id);
        }
        catch (DataIntegrityViolationException e) {
            throw new EntidadeEmUsoException(String.format("Anúncio ou código %d não pode ser removido, pois está em uso.", id));
        }
        catch (EmptyResultDataAccessException e) {
            throw new EntidadeNaoEncontradaException(String.format("Não existe cadastro de anúncio com código %d", id));
        }
    }
}
