package com.api.AgroTech.api.controller;

import com.api.AgroTech.domain.model.FotoServico;
import com.api.AgroTech.domain.model.Servico;
import com.api.AgroTech.domain.repository.FotoServicoRepository;
import com.api.AgroTech.domain.repository.ServicoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/fotos-servico")
@CrossOrigin(origins = "*")
public class FotoServicoController {

    @Autowired
    private FotoServicoRepository fotoServicoRepository;

    @Autowired
    private ServicoRepository servicoRepository;

    // Upload de uma única foto
    @PostMapping(value = "/{servicoId}/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> uploadFoto(
            @PathVariable Long servicoId,
            @RequestPart("file") MultipartFile file
    ) {
        try {
            Servico servico = servicoRepository.findById(servicoId)
                    .orElseThrow(() -> new RuntimeException("Serviço não encontrado: " + servicoId));

            if (file == null || file.isEmpty()) {
                return ResponseEntity.badRequest().body("Arquivo vazio ou não enviado");
            }

            FotoServico foto = new FotoServico();
            foto.setServico(servico);
            foto.setConteudo(file.getBytes());
            foto.setNomeArquivo(file.getOriginalFilename());
            foto.setTipoConteudo(file.getContentType());
            foto.setDataUpload(LocalDateTime.now());

            fotoServicoRepository.save(foto);

            return ResponseEntity.ok("Foto enviada com sucesso!");
        } catch (IOException e) {
            return ResponseEntity.status(500).body("Erro ao enviar foto: " + e.getMessage());
        }
    }

    // Upload de múltiplas fotos
    @PostMapping(value = "/{servicoId}/upload-multiple", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> uploadFotos(
            @PathVariable Long servicoId,
            @RequestPart("files") List<MultipartFile> files
    ) {
        Servico servico = servicoRepository.findById(servicoId)
                .orElseThrow(() -> new RuntimeException("Serviço não encontrado com ID: " + servicoId));

        try {
            for (MultipartFile file : files) {
                if (file == null || file.isEmpty()) continue;

                FotoServico foto = new FotoServico();
                foto.setServico(servico);
                foto.setConteudo(file.getBytes());
                foto.setNomeArquivo(file.getOriginalFilename());
                foto.setTipoConteudo(file.getContentType());
                foto.setDataUpload(LocalDateTime.now());

                fotoServicoRepository.save(foto);
            }
            return ResponseEntity.ok("Fotos enviadas com sucesso!");
        } catch (IOException e) {
            return ResponseEntity.status(500).body("Erro ao enviar fotos: " + e.getMessage());
        }
    }

    // Retornar foto pelo ID
    @GetMapping("/file/{fotoId}")
    public ResponseEntity<byte[]> getFoto(@PathVariable Long fotoId) {
        FotoServico foto = fotoServicoRepository.findById(fotoId)
                .orElseThrow(() -> new RuntimeException("Foto não encontrada: " + fotoId));

        return ResponseEntity.ok()
                .header("Content-Type", foto.getTipoConteudo())
                .body(foto.getConteudo());
    }

    // Listar fotos de um serviço
    @GetMapping("/servico/{servicoId}")
    public ResponseEntity<List<FotoServico>> listarFotos(@PathVariable Long servicoId) {
        Servico servico = servicoRepository.findById(servicoId)
                .orElseThrow(() -> new RuntimeException("Serviço não encontrado: " + servicoId));

        List<FotoServico> fotos = servico.getFotos();
        return ResponseEntity.ok(fotos);
    }
}
