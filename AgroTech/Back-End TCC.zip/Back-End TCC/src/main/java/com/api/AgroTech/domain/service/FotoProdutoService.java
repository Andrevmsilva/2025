package com.api.AgroTech.domain.service;

import com.api.AgroTech.domain.exception.EntidadeNaoEncontradaException;
import com.api.AgroTech.domain.exception.EntidadeEmUsoException;
import com.api.AgroTech.domain.model.FotoProduto;
import com.api.AgroTech.domain.model.Produto;
import com.api.AgroTech.domain.repository.FotoProdutoRepository;
import com.api.AgroTech.domain.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@Service
public class FotoProdutoService {

    @Autowired
    private FotoProdutoRepository fotoProdutoRepository;

    @Autowired
    private ProdutoRepository produtoRepository;

    private final String uploadDir = "uploads/";

    public FotoProduto salvar(FotoProduto fotoProduto) {
        return fotoProdutoRepository.save(fotoProduto);
    }

    public void excluir(Long id) {
        try {
            fotoProdutoRepository.deleteById(id);
        } catch (DataIntegrityViolationException e) {
            throw new EntidadeEmUsoException(
                    String.format("Foto de Produto ou código %d não pode ser removido, pois está em uso.", id)
            );
        } catch (EmptyResultDataAccessException e) {
            throw new EntidadeNaoEncontradaException(
                    String.format("Não existe cadastro de foto de produto com código %d", id)
            );
        }
    }

    // Novo método para salvar fotos físicas e registrar no banco
    public void salvarFotos(Long produtoId, MultipartFile[] files) throws IOException {
        Produto produto = produtoRepository.findById(produtoId)
                .orElseThrow(() -> new EntidadeNaoEncontradaException("Produto não encontrado"));

        File dir = new File(uploadDir);
        if (!dir.exists()) dir.mkdirs();

        for (MultipartFile file : files) {
            String nomeArquivo = System.currentTimeMillis() + "_" + file.getOriginalFilename();
            File destino = new File(dir, nomeArquivo);
            file.transferTo(destino);

            FotoProduto foto = new FotoProduto();
            foto.setProduto(produto);
            foto.setCaminhoArquivo(destino.getPath());
            fotoProdutoRepository.save(foto);
        }
    }
}
