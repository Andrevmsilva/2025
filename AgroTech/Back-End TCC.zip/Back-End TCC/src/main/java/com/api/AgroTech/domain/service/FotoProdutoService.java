package com.api.AgroTech.domain.service;

import com.api.AgroTech.domain.exception.EntidadeNaoEncontradaException;
import com.api.AgroTech.domain.model.FotoProduto;
import com.api.AgroTech.domain.model.Produto;
import com.api.AgroTech.domain.repository.FotoProdutoRepository;
import com.api.AgroTech.domain.repository.ProdutoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class FotoProdutoService {

    private final FotoProdutoRepository fotoProdutoRepository;
    private final ProdutoRepository produtoRepository;

    public FotoProdutoService(FotoProdutoRepository fotoProdutoRepository,
                              ProdutoRepository produtoRepository) {
        this.fotoProdutoRepository = fotoProdutoRepository;
        this.produtoRepository = produtoRepository;
    }

    // ✅ Upload de múltiplas fotos
    @Transactional
    public void salvarFotos(Long produtoId, List<MultipartFile> files) throws IOException {
        Produto produto = produtoRepository.findById(produtoId)
                .orElseThrow(() -> new EntidadeNaoEncontradaException(
                        "Produto não encontrado com ID: " + produtoId));

        for (MultipartFile file : files) {
            FotoProduto foto = new FotoProduto();
            foto.setProduto(produto);
            foto.setConteudo(file.getBytes());
            foto.setNomeArquivo(file.getOriginalFilename());
            foto.setTipoConteudo(file.getContentType());
            foto.setDataUpload(LocalDateTime.now());

            fotoProdutoRepository.save(foto);
        }
    }

    // ✅ Buscar foto pelo ID
    public Optional<FotoProduto> buscarPorId(Long fotoId) {
        return fotoProdutoRepository.findById(fotoId);
    }

    // ✅ Buscar foto pelo nome
    public Optional<FotoProduto> buscarPorNome(String nomeArquivo) {
        return fotoProdutoRepository.findByNomeArquivo(nomeArquivo);
    }

    // ✅ Listar todas as fotos de um produto
    public List<FotoProduto> listarFotosPorProduto(Long produtoId) {
        Produto produto = produtoRepository.findById(produtoId)
                .orElseThrow(() -> new EntidadeNaoEncontradaException(
                        "Produto não encontrado com ID: " + produtoId));
        return fotoProdutoRepository.findByProduto(produto);
    }

    // ✅ Remover foto
    @Transactional
    public void excluir(Long fotoId) {
        FotoProduto foto = fotoProdutoRepository.findById(fotoId)
                .orElseThrow(() -> new EntidadeNaoEncontradaException(
                        "Foto não encontrada com ID: " + fotoId));
        fotoProdutoRepository.delete(foto);
    }
}
