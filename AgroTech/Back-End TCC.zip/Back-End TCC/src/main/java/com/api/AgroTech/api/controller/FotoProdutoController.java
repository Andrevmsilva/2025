package com.api.AgroTech.api.controller;

import com.api.AgroTech.domain.model.FotoProduto;
import com.api.AgroTech.domain.model.Produto;
import com.api.AgroTech.domain.repository.FotoProdutoRepository;
import com.api.AgroTech.domain.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/fotos-produto")
@CrossOrigin(origins = "*") // 🌐 CORREÇÃO 3: Permite acesso do Front-end (ex: localhost:5173 ou 3000)
public class FotoProdutoController {

    @Autowired
    private FotoProdutoRepository fotosProdutoRepository;

    @Autowired
    private ProdutoRepository produtoRepository;

    // Upload de múltiplas fotos
    @PostMapping("/{produtoId}/upload-multiple")
    public ResponseEntity<String> uploadFotos(
            @PathVariable Long produtoId,
            @RequestParam("files") List<MultipartFile> files
    ) {
        Produto produto = produtoRepository.findById(produtoId)
                .orElseThrow(() -> new RuntimeException("Produto não encontrado com ID: " + produtoId));

        try {
            for (MultipartFile file : files) {
                FotoProduto foto = new FotoProduto();
                foto.setProduto(produto);
                foto.setConteudo(file.getBytes());
                foto.setNomeArquivo(file.getOriginalFilename());
                foto.setTipoConteudo(file.getContentType());
                foto.setDataUpload(LocalDateTime.now());

                fotosProdutoRepository.save(foto);
            }

            return ResponseEntity.ok("Fotos enviadas com sucesso!");
        } catch (IOException e) {
            return ResponseEntity.status(500).body("Erro ao enviar fotos: " + e.getMessage());
        }
    }

    // Retornar foto pelo ID - Este endpoint está correto e retorna o arquivo de imagem
    @GetMapping("/file/{fotoId}")
    public ResponseEntity<byte[]> getFoto(@PathVariable Long fotoId) {
        FotoProduto foto = fotosProdutoRepository.findById(fotoId)
                .orElseThrow(() -> new RuntimeException("Foto não encontrada: " + fotoId));

        return ResponseEntity.ok()
                .header("Content-Type", foto.getTipoConteudo())
                .body(foto.getConteudo());
    }
}