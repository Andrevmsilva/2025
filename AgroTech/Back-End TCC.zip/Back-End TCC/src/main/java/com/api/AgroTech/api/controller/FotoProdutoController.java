package com.api.AgroTech.api.controller;

import com.api.AgroTech.domain.model.FotoProduto;
import com.api.AgroTech.domain.service.FotoProdutoService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/fotos-produto")
@CrossOrigin(origins = "http://localhost:3000") // ajuste se sua porta React for diferente
public class FotoProdutoController {

    private final FotoProdutoService fotoProdutoService;

    public FotoProdutoController(FotoProdutoService fotoProdutoService) {
        this.fotoProdutoService = fotoProdutoService;
    }

    // ✅ Upload de múltiplas fotos para um produto
    @PostMapping("/upload-multiple/{produtoId}")
    public ResponseEntity<String> uploadFotos(
            @PathVariable Long produtoId,
            @RequestParam("files") List<MultipartFile> files
    ) throws IOException {
        fotoProdutoService.salvarFotos(produtoId, files);
        return ResponseEntity.ok("Fotos enviadas com sucesso!");
    }

    // ✅ Listar todas as fotos de um produto
    @GetMapping("/produto/{produtoId}")
    public ResponseEntity<List<FotoProduto>> listarFotosProduto(@PathVariable Long produtoId) {
        List<FotoProduto> fotos = fotoProdutoService.listarFotosPorProduto(produtoId);
        return ResponseEntity.ok(fotos);
    }

    // ✅ Baixar/visualizar foto pelo ID
    @GetMapping("/file/{fotoId}")
    public ResponseEntity<byte[]> buscarFoto(@PathVariable Long fotoId) {
        FotoProduto foto = fotoProdutoService.buscarPorId(fotoId)
                .orElseThrow(() -> new RuntimeException("Foto não encontrada"));

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_TYPE, foto.getTipoConteudo())
                .body(foto.getConteudo());
    }

    // ✅ Excluir uma foto pelo ID
    @DeleteMapping("/{fotoId}")
    public ResponseEntity<String> excluirFoto(@PathVariable Long fotoId) {
        fotoProdutoService.excluir(fotoId);
        return ResponseEntity.ok("Foto removida com sucesso");
    }
}
