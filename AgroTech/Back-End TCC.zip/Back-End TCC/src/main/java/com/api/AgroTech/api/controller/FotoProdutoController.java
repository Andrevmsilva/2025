package com.api.AgroTech.api.controller;

import com.api.AgroTech.domain.model.FotoProduto;
import com.api.AgroTech.domain.model.Produto;
import com.api.AgroTech.domain.repository.FotoProdutoRepository;
import com.api.AgroTech.domain.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
@RequestMapping("/foto-produto")
public class FotoProdutoController {

    @Autowired
    private FotoProdutoRepository fotoProdutoRepository;

    @Autowired
    private ProdutoRepository produtoRepository;

    // Novo endpoint para upload de múltiplos arquivos
    @PostMapping("/upload")
    public ResponseEntity<?> uploadFotos(
            @RequestParam("produtoId") Long produtoId,
            @RequestParam("files") MultipartFile[] files
    ) throws IOException {

        Produto produto = produtoRepository.findById(produtoId)
                .orElseThrow(() -> new RuntimeException("Produto não encontrado"));

        for (MultipartFile file : files) {
            String nomeArquivo = System.currentTimeMillis() + "_" + file.getOriginalFilename();
            Path caminho = Paths.get("uploads/" + nomeArquivo);

            Files.createDirectories(caminho.getParent());
            Files.write(caminho, file.getBytes());

            FotoProduto foto = new FotoProduto();
            foto.setProduto(produto);
            foto.setCaminhoArquivo(caminho.toString());
            fotoProdutoRepository.save(foto);
        }

        return ResponseEntity.ok("Fotos salvas com sucesso!");
    }
}
