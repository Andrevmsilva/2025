package com.api.AgroTech.domain.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "produto")
public class Produto {

    @EqualsAndHashCode.Include
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Nome do produto
    @Column(name = "nome_produto")
    private String nome;

    // NOVOS CAMPOS para funcionar com o frontend
    @Column(columnDefinition = "TEXT")
    private String descricao;

    private String localizacao;

    private Double preco;

    @Column(name = "email_contato")
    private String emailContato;

    @Column(name = "telefone_contato")
    private String telefoneContato;

    // Esses campos agora são opcionais
    @ManyToOne(optional = true)
    @JoinColumn(name = "tipo_produto_id")
    private TipoProduto tipoProduto;

    @ManyToOne(optional = true)
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;
}
