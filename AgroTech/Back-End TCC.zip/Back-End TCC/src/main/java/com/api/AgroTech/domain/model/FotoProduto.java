package com.api.AgroTech.domain.model;

import com.api.AgroTech.domain.model.Produto;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "foto_produto")
public class FotoProduto {

    @EqualsAndHashCode.Include
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "produto_id", nullable = false)
    private Produto produto;

    @Column(nullable = false)
    private String caminhoArquivo; // ex: "uploads/produto123.jpg"

    @Column(nullable = false)
    private LocalDateTime dataUpload;

    // Construtor padrão
    public FotoProduto() {
        this.dataUpload = LocalDateTime.now();
    }
}
