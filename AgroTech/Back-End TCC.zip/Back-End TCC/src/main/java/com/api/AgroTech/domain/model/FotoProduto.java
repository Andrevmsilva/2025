package com.api.AgroTech.domain.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "foto_produto")
public class FotoProduto {

    @EqualsAndHashCode.Include
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nomeArquivo;

    private String tipoConteudo;

    @Lob
    private byte[] conteudo;

    private LocalDateTime dataUpload;

    @ManyToOne
    @JoinColumn(name = "produto_id")
    private Produto produto;
}
