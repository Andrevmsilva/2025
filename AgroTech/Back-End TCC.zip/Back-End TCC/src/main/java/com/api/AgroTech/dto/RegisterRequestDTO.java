package com.api.AgroTech.dto;

public record RegisterRequestDTO(
        String nome,
        String email,
        String senha,
        String cpf_cnpj,
        String logradouro,
        String numero,
        String bairro,
        String complemento,
        Long cidadeId
) {}
