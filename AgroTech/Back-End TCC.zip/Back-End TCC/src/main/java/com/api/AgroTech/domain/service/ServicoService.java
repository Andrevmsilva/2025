package com.api.AgroTech.domain.service;

import com.api.AgroTech.domain.exception.EntidadeEmUsoException;
import com.api.AgroTech.domain.exception.EntidadeNaoEncontradaException;
import com.api.AgroTech.domain.model.Servico;
import com.api.AgroTech.domain.repository.ServicoRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ServicoService {

    private final ServicoRepository servicoRepository;

    public ServicoService(ServicoRepository servicoRepository) {
        this.servicoRepository = servicoRepository;
    }

    public List<Servico> listarTodos() {
        return servicoRepository.findAll();
    }

    public Optional<Servico> buscarPorId(Long id) {
        return servicoRepository.findById(id);
    }

    public Servico salvar(Servico servico) {
        return servicoRepository.save(servico);
    }

    public Optional<Servico> atualizar(Long id, Servico servicoAtualizado) {
        return servicoRepository.findById(id)
                .map(servicoExistente -> {
                    servicoExistente.setNome(servicoAtualizado.getNome());
                    servicoExistente.setDescricao(servicoAtualizado.getDescricao());
                    servicoExistente.setPreco(servicoAtualizado.getPreco());
                    servicoExistente.setLocalizacao(servicoAtualizado.getLocalizacao());
                    servicoExistente.setEmailContato(servicoAtualizado.getEmailContato());
                    servicoExistente.setTelefoneContato(servicoAtualizado.getTelefoneContato());
                    servicoExistente.setCliente(servicoAtualizado.getCliente());
                    return servicoRepository.save(servicoExistente);
                });
    }

    public void excluir(Long id) throws EntidadeNaoEncontradaException, EntidadeEmUsoException {
        try {
            if (!servicoRepository.existsById(id)) {
                throw new EntidadeNaoEncontradaException(
                        String.format("Serviço de id %d não encontrado", id));
            }
            servicoRepository.deleteById(id);
        } catch (DataIntegrityViolationException e) {
            throw new EntidadeEmUsoException(
                    String.format("Serviço de id %d não pode ser removido, pois está em uso", id));
        }
    }
}
