package com.api.AgroTech.domain.service;

import com.api.AgroTech.domain.exception.EntidadeEmUsoException;
import com.api.AgroTech.domain.exception.EntidadeNaoEncontradaException;
import com.api.AgroTech.domain.model.Servico;
import com.api.AgroTech.domain.repository.ServicoRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ServicoService {

    private final ServicoRepository servicoRepository;

    public ServicoService(ServicoRepository servicoRepository) {
        this.servicoRepository = servicoRepository;
    }

    // Listar todos os serviços
    public List<Servico> listarTodos() {
        return servicoRepository.findAll();
    }

    // Buscar serviço por ID
    public Optional<Servico> buscarPorId(Long servicoId) {
        return servicoRepository.findById(servicoId);
    }

    // Salvar novo serviço
    public Servico salvar(Servico servico) {
        return servicoRepository.save(servico);
    }

    // Atualizar serviço existente
    public Optional<Servico> atualizar(Long servicoId, Servico servicoAtualizado) {
        return servicoRepository.findById(servicoId)
                .map(servicoExistente -> {
                    servicoExistente.setNome(servicoAtualizado.getNome());
                    servicoExistente.setDescricao(servicoAtualizado.getDescricao());
                    servicoExistente.setPreco(servicoAtualizado.getPreco());
                    servicoExistente.setLocalizacao(servicoAtualizado.getLocalizacao());
                    servicoExistente.setEmailContato(servicoAtualizado.getEmailContato());
                    servicoExistente.setTelefoneContato(servicoAtualizado.getTelefoneContato());
                    return servicoRepository.save(servicoExistente);
                });
    }

    // Excluir serviço
    public void excluir(Long servicoId) throws EntidadeNaoEncontradaException, EntidadeEmUsoException {
        try {
            if (!servicoRepository.existsById(servicoId)) {
                throw new EntidadeNaoEncontradaException(
                        String.format("Serviço de id %d não encontrado", servicoId));
            }
            servicoRepository.deleteById(servicoId);
        } catch (DataIntegrityViolationException e) {
            throw new EntidadeEmUsoException(
                    String.format("Serviço de id %d não pode ser removido, pois está em uso", servicoId));
        }
    }
}
