CREATE TABLE estado (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    sigla CHAR(2),
    nome VARCHAR(50)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE cidade (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120),
    estado_id INT NOT NULL,
    CONSTRAINT fk_cidade_estado FOREIGN KEY (estado_id) REFERENCES estado(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE cliente (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    cpf_cnpj VARCHAR(100),
    logradouro VARCHAR(100),
    numero VARCHAR(10),
    bairro VARCHAR(255),
    complemento VARCHAR(120),
    email VARCHAR(255) UNIQUE,
    senha VARCHAR(255),
    cidade_id INT NOT NULL,
    CONSTRAINT fk_cliente_cidade FOREIGN KEY (cidade_id) REFERENCES cidade(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE tipo_produto (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    descricao VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE produto (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_produto VARCHAR(255) NOT NULL,
    descricao TEXT,
    localizacao VARCHAR(255),
    preco DECIMAL(10,2),
    email_contato VARCHAR(255),
    telefone_contato VARCHAR(50),
    estoque INT,
    tipo_produto_id INT,
    cliente_id INT,
    CONSTRAINT fk_produto_tipo_produto FOREIGN KEY (tipo_produto_id) REFERENCES tipo_produto(id),
    CONSTRAINT fk_produto_cliente FOREIGN KEY (cliente_id) REFERENCES cliente(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE foto_produto (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    produto_id INT NOT NULL,
    conteudo LONGBLOB NOT NULL,
    tipo_conteudo VARCHAR(100) NOT NULL,
    nome_arquivo VARCHAR(255) NOT NULL,
    data_upload DATETIME NOT NULL,
    CONSTRAINT fk_foto_produto_produto FOREIGN KEY (produto_id) REFERENCES produto(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE anuncio (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(120),
    descricao VARCHAR(100),
    produto_id INT NOT NULL,
    preco DECIMAL(12,2),
    status VARCHAR(100),
    CONSTRAINT fk_anuncio_produto FOREIGN KEY (produto_id) REFERENCES produto(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
