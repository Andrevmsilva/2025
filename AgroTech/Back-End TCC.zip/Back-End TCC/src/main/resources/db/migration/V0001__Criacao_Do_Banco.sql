CREATE TABLE estado (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    sigla CHAR(2),
    nome VARCHAR(50)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE cidade (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120),
    estado_id INT NOT NULL,
    CONSTRAINT fk_cidade_estado FOREIGN KEY (estado_id) REFERENCES estado(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE cliente (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    cpf_cnpj VARCHAR(100),
    logradouro VARCHAR(100),
    numero VARCHAR(10),
    bairro VARCHAR(255),
    complemento VARCHAR(120),
    email VARCHAR(255) UNIQUE,
    senha VARCHAR(255),
    cidade_id INT NOT NULL,
    CONSTRAINT fk_cliente_cidade FOREIGN KEY (cidade_id) REFERENCES cidade(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE tipo_produto (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    descricao VARCHAR(255)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE produto (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome_produto VARCHAR(255) NOT NULL,
    descricao TEXT,
    localizacao VARCHAR(255),
    preco DECIMAL(10,2),
    email_contato VARCHAR(255),
    telefone_contato VARCHAR(50),
    estoque INT,
    tipo_produto_id INT,
    cliente_id INT,
    CONSTRAINT fk_produto_tipo_produto FOREIGN KEY (tipo_produto_id) REFERENCES tipo_produto(id),
    CONSTRAINT fk_produto_cliente FOREIGN KEY (cliente_id) REFERENCES cliente(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE foto_produto (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    produto_id INT NOT NULL,
    conteudo LONGBLOB NOT NULL,
    tipo_conteudo VARCHAR(100) NOT NULL,
    nome_arquivo VARCHAR(255) NOT NULL,
    data_upload DATETIME NOT NULL,
    CONSTRAINT fk_foto_produto_produto FOREIGN KEY (produto_id) REFERENCES produto(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE anuncio (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(120),
    descricao VARCHAR(100),
    produto_id INT NOT NULL,
    preco DECIMAL(12,2),
    status VARCHAR(100),
    CONSTRAINT fk_anuncio_produto FOREIGN KEY (produto_id) REFERENCES produto(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE servico (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    localizacao VARCHAR(255),
    preco DECIMAL(10,2),
    email_contato VARCHAR(255),
    telefone_contato VARCHAR(50),
    cliente_id INT,
    CONSTRAINT fk_servico_cliente FOREIGN KEY (cliente_id) REFERENCES cliente(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE foto_servico (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    servico_id INT NOT NULL,
    conteudo LONGBLOB NOT NULL,
    tipo_conteudo VARCHAR(100) NOT NULL,
    nome_arquivo VARCHAR(255) NOT NULL,
    data_upload DATETIME NOT NULL,
    CONSTRAINT fk_foto_servico_servico FOREIGN KEY (servico_id) REFERENCES servico(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO tipo_produto (descricao) VALUES ('Geral');
INSERT INTO tipo_produto (descricao) VALUES ('Maquinário');
INSERT INTO tipo_produto (descricao) VALUES ('Peça');

INSERT INTO estado (id, nome) VALUES (1, 'Estado Teste');
INSERT INTO cidade (id, nome, estado_id) VALUES (1, 'Cidade Teste', 1);

INSERT INTO cliente (nome, cpf_cnpj, logradouro, numero, bairro, complemento, email, senha, cidade_id)
VALUES ('Usuário Teste', '12345678900', 'Rua Teste', '100', 'Centro', 'Apto 1', 'usuario@gmail.com', '123', 1);

INSERT INTO produto (nome_produto, descricao, localizacao, preco, email_contato, telefone_contato, estoque, tipo_produto_id, cliente_id) VALUES
('Produto 1', 'Descrição 1', 'Cidade A', 100, 'usuario@gmail.com', '1111-1111', 10, 1, 1),
('Produto 2', 'Descrição 2', 'Cidade B', 200, 'usuario@gmail.com', '1111-1112', 5, 2, 1),
('Produto 3', 'Descrição 3', 'Cidade C', 300, 'usuario@gmail.com', '1111-1113', 15, 3, 1),
('Produto 4', 'Descrição 4', 'Cidade A', 400, 'usuario@gmail.com', '1111-1114', 8, 1, 1),
('Produto 5', 'Descrição 5', 'Cidade B', 500, 'usuario@gmail.com', '1111-1115', 20, 2, 1),
('Produto 6', 'Descrição 6', 'Cidade C', 600, 'usuario@gmail.com', '1111-1116', 12, 3, 1),
('Produto 7', 'Descrição 7', 'Cidade A', 700, 'usuario@gmail.com', '1111-1117', 7, 1, 1),
('Produto 8', 'Descrição 8', 'Cidade B', 800, 'usuario@gmail.com', '1111-1118', 9, 2, 1),
('Produto 9', 'Descrição 9', 'Cidade C', 900, 'usuario@gmail.com', '1111-1119', 3, 3, 1),
('Produto 10', 'Descrição 10', 'Cidade A', 1000, 'usuario@gmail.com', '1111-1120', 11, 1, 1),
('Produto 11', 'Descrição 11', 'Cidade B', 1100, 'usuario@gmail.com', '1111-1121', 14, 2, 1),
('Produto 12', 'Descrição 12', 'Cidade C', 1200, 'usuario@gmail.com', '1111-1122', 6, 3, 1);


INSERT INTO servico (nome, descricao, localizacao, preco, email_contato, telefone_contato, cliente_id) VALUES
('Serviço 1', 'Serviço descrição 1', 'Cidade A', 150, 'usuario@gmail.com', '2222-1111', 1),
('Serviço 2', 'Serviço descrição 2', 'Cidade B', 250, 'usuario@gmail.com', '2222-1112', 1),
('Serviço 3', 'Serviço descrição 3', 'Cidade C', 350, 'usuario@gmail.com', '2222-1113', 1),
('Serviço 4', 'Serviço descrição 4', 'Cidade A', 450, 'usuario@gmail.com', '2222-1114', 1),
('Serviço 5', 'Serviço descrição 5', 'Cidade B', 550, 'usuario@gmail.com', '2222-1115', 1),
('Serviço 6', 'Serviço descrição 6', 'Cidade C', 650, 'usuario@gmail.com', '2222-1116', 1),
('Serviço 7', 'Serviço descrição 7', 'Cidade A', 750, 'usuario@gmail.com', '2222-1117', 1),
('Serviço 8', 'Serviço descrição 8', 'Cidade B', 850, 'usuario@gmail.com', '2222-1118', 1),
('Serviço 9', 'Serviço descrição 9', 'Cidade C', 950, 'usuario@gmail.com', '2222-1119', 1),
('Serviço 10', 'Serviço descrição 10', 'Cidade A', 1050, 'usuario@gmail.com', '2222-1120', 1),
('Serviço 11', 'Serviço descrição 11', 'Cidade B', 1150, 'usuario@gmail.com', '2222-1121', 1),
('Serviço 12', 'Serviço descrição 12', 'Cidade C', 1250, 'usuario@gmail.com', '2222-1122', 1);


INSERT INTO foto_produto (produto_id, conteudo, tipo_conteudo, nome_arquivo, data_upload)
SELECT id, '', 'image/png', CONCAT('produto_', id, '.png'), NOW() FROM produto;

INSERT INTO foto_servico (servico_id, conteudo, tipo_conteudo, nome_arquivo, data_upload)
SELECT id, '', 'image/png', CONCAT('servico_', id, '.png'), NOW() FROM servico;