package Andre.example.EscolaApiTA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EscolaApiTaApplicationTests {

	@Test
	void contextLoads() {
	}

}
