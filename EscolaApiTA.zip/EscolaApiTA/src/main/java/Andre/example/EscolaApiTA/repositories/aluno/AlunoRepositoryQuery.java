package Andre.example.EscolaApiTA.repositories.aluno;public interface AlunoRepositoryQuery {
}
