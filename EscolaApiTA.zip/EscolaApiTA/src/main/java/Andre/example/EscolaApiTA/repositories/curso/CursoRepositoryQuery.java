package Andre.example.EscolaApiTA.repositories.curso;public interface CursoRepositoryQuery {
}
