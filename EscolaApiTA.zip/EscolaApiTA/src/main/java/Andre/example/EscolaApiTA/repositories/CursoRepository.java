package Andre.example.EscolaApiTA;public interface CursoRepository {
}
