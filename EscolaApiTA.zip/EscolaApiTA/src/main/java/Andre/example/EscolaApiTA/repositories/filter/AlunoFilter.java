package Andre.example.EscolaApiTA.repositories.filter;public class AlunoFilter {
}
