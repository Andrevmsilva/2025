package Andre.example.EscolaApiTA.repositories.aluno;public class AlunoRepositoryImpl {
}
