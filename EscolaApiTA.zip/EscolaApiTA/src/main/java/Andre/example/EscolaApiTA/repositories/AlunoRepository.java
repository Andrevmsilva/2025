package Andre.example.EscolaApiTA.repositories;public interface AlunoRepository {
}
