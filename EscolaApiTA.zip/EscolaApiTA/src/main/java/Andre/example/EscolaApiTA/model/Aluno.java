package Andre.example.EscolaApiTA.model;public class Aluno {
}
