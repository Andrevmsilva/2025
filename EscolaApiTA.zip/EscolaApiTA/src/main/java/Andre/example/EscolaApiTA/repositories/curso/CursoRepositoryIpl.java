package Andre.example.EscolaApiTA.repositories.curso;public class CursoRepositoryIpl {
}
