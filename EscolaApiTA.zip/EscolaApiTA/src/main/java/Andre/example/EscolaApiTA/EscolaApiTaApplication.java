package Andre.example.EscolaApiTA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EscolaApiTaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EscolaApiTaApplication.class, args);
	}

}
