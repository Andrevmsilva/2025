import 'package:flutter/material.dart';
import 'dart:math';

void main () => runApp(const Apli());


class Apli extends StatelessWidget {
  const Apli({super.key});
  @override
  Widget build(BuildContext context) {
    
    return MaterialApp(
      home: const Prime(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class Prime extends StatefulWidget{
  const Prime({super.key});

  @override
  State<Prime> createState() =>  _PrimeStatte();
  
}

class _PrimeStatte extends State<Prime> {
 double _a = 0.0;
 double _b = 0.0;
 double _c = 0.0;
 double _x1 = 0.0;
 double _x2 = 0.0;

  @override
  Widget build(BuildContext context) {
    return  Scaffold(

      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 26, 78, 131),
        title: Text("Bhaskara Calculator",
        style: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w500),
        ),),

       body: Column(
        mainAxisAlignment:  MainAxisAlignment.center,
        children: [
          Text("Calcular as raizes de:",
          style: TextStyle(fontSize: 24),),
          Padding(
            padding: const EdgeInsets.only(bottom: 30),
            child: Text('ax^2+bx+c = 0', style: TextStyle(fontSize: 20),),
          ),


         
 Padding(
            padding: const EdgeInsets.symmetric(vertical: 20,
            horizontal: 55),
            child: TextField(
              textAlign: TextAlign.center,
              onChanged: (value) { 
                setState(() {
                  _a = double.parse(value);
                });
              },
              
              decoration: 
              InputDecoration(label: Text("Entre com o valor de A"),
              border: OutlineInputBorder()
              ),
            ),
          ),

           Padding(
            padding: const EdgeInsets.symmetric(vertical: 20,
            horizontal: 55),
            child: TextField(
               textAlign: TextAlign.center,
              onChanged: (value) { 
                setState(() {
                    _b = double.parse(value);
                });
              },
              
              decoration: 
              InputDecoration(label: Text("Entre com o valor de B"),
              border: OutlineInputBorder()
              ),
            ),
          ),

          Padding(
            padding: const EdgeInsets.symmetric(vertical: 20,
            horizontal: 55),
            child: TextField(
               textAlign: TextAlign.center,
              onChanged: (value) { 
                setState(() {
                    _c = double.parse(value);
                });
              },
              
              decoration: 
              InputDecoration(label: Text("Entre com o valor de C"),
              border: OutlineInputBorder()
              ),
            ),
          ),
          ElevatedButton(
            onPressed: (){
             setState(() {
               double delta = _b * _b - 4 * _a *_c;
             _x1 = (-_b + sqrt(delta)) / 2 * _a;
             _x2 = (-_b - sqrt(delta)) / 2 * _a;
             });
            },
           child: Text("Calcular Raizes")
           ),
           Text("x1 = $_x1"),
           Text("x2 = $_x2"),
        ],
      ),
    ); 
  }
}