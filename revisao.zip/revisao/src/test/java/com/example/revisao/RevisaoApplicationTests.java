package com.example.revisao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RevisaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
