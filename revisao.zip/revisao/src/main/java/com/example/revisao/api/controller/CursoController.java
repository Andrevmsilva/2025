package com.example.revisao.api.controller;

public class CursoController {
}
