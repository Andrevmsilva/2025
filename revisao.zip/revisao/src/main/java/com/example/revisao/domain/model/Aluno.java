package com.example.revisao.domain.model;

public class Aluno {
}
