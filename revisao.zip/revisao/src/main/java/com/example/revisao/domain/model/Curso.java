package com.example.revisao.domain.model;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;

@Table (name="Curso")
public class Curso {

    @EqualsAndHashCode.Include
    @Id
    @GeneratedValue(strategy =  GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "nome_curso", length = 100)
    private String nome;
}
