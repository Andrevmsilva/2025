import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:8080', // A API AgroTech está rodando na porta 8080
});

export default api;
