//import {FaUser, FaLock} from 'react-icons/fa';
//import { HiMiniIdentification } from "react-icons/hi2";

import { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Link } from "react-router-dom";


import './Login.css'

export default function Login () {
    const { login } = useAuth();
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [documentation, setDocumentation] = useState("");

    const handleSubmit = async (event) => {
        event.preventDefault();

       const success = await login(email, password);
	        if (success) {
	            navigate('/home');
	        } else {
	            alert("Falha no login. Verifique suas credenciais.");
	        }
    };

    return (
        <div className="cont">
        <div className="container">

            <form onSubmit={handleSubmit}>
                <h1>Acesse o Sistema</h1>
                <div className="input-field">
                    <input 
                    type="email" 
                    placeholder="E-mail"
                    required
                    onChange={(e) => setEmail(e.target.value)} 
                     />
                   
                </div>

                <div className="input-field">
                    <input 
                    type="password" 
                    placeholder="Senha" 
                    onChange={(e) => setPassword(e.target.value)} 
                     />
                   
                </div>

                <div className='input-field'>
                    <input 
                    type="text" 
                    placeholder="CPF/CNPJ" 
                    onChange={(e) => setDocumentation(e.target.value)} 
                    />
                    
                </div>
                
                <div className="recall-forget">
                    <label>
                        <input type="checkbox" />
                        Lembre de mim
                    </label>
                    <a href="#">Esqueceu a Senha?</a>
                </div>

                <button type="submit">Entrar</button>

                <div className="signup-link">
                    <p>Não tem uma conta?</p> 
                    <Link to="/Cadastro"><div className='cor'>Cadastrar</div></Link>
                </div>
            </form>
        </div>
        </div>
    );
}
