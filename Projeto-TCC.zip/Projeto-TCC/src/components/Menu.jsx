// Menu.jsx
import { useState, useRef, useEffect } from "react";
import styles from "./Menu.module.css";

export default function Menu() {
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef(null);

  // Fecha o dropdown ao clicar fora
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className={styles.container}>
      <div className={styles.conteudo}>
        <div
          className={styles.c1}
          ref={dropdownRef}
          onClick={() => setOpen((prev) => !prev)}
        >
          Produtos
          {open && (
            <div className={styles.drop}>
              <a href="#"><div>Serviços</div></a>
              <a href="#"><div>Maquinários</div></a>
              <a href="#"><div>Peças</div></a>
            </div>
          )}
        </div>
        <div className={styles.c3}>Vender</div>
        <div className={styles.c4}>Contato</div>
        <div className={styles.c5}>Conta</div>
      </div>
    </div>
  );
}
