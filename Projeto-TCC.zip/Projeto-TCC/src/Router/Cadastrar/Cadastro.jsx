import Topo from '../../components/Topo'
import Menu from '../../components/Menu'
import Cadastrar from '../../components/Cadastrar'


import './Cadastro.module.css';

export default function Cadastro() {


    return (
      <div className="App">
        <div><Cadastrar/></div>
      </div>
    );
  }