package com.Andre.foodta.domain.repository;public interface CidadeRepository {
}
