package com.Andre.foodta.domain.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Data
@Embeddable
public class Endereco {
    @NotBlank(message = "O CEP é obrigatorio!")
    @Column(name = "endereco_cep")
    private String cep;
    @NotBlank(message = "O nome da rua é obrigatorio!")
    @Column(name = "endereco_logradouro")
    private String logradouro;
    @NotBlank(message = "O número é obrigatorio!")
    @NotBlank(message = "")
    @Column(name = "endereco_numero")
    private String numero;

    @Column(name = "endereco_complemento")
    private String complemento;
    @NotBlank(message = "O nome do bairro é obrigatorio!")
    @Column(name = "endereco_bairro")
    private String bairro;

    @ManyToOne
    @JoinColumn(name = "endereco_cidade_id")
    private Cidade cidade;

}
