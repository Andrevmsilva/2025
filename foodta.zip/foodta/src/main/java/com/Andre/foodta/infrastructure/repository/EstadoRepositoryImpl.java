package com.Andre.foodta.infrastructure.repository;public class EstadoRepositoryImpl {
}
