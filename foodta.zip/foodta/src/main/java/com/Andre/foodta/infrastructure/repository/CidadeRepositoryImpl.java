package com.Andre.foodta.infrastructure.repository;

import com.Andre.foodta.domain.model.Cidade;
import com.Andre.foodta.domain.repository.CidadeRepository;
import jakarta.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
@Component
public class CidadeRepositoryImpl implements CidadeRepository {

    @Autowired
    private EntityManager manager;

    @Override
    public List<Cidade> listar() {
        return manager.createQuery("from Cidade", Cidade.class).getResultList();
    }

    @Override
    public Cidade buscar(Long id) {
        return null;
    }

    @Override
    public Cidade salvar(Cidade cidade) {
        return null;
    }

    @Override
    public void remover(Long id) {

    }
}
