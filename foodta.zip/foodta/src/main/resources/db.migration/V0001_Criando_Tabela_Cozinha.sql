Create Table tb_cozinha(
id bigint not null auto_increment,
nome_cozinha varchar(70)
primary key(id)
) engine=InnoDB default charset=utfB;

Create Table tb_restaurante(
id bigint not null auto_increment,
nome varchar(70)
taxa_frete decimal(12.2) not null
cozinha_id bigint not null auto_increment;
primary key (id)
)engine=InnoDB default charset=utfB;

