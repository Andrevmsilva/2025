insert into tb_cozinha(nome_cozinha) values ('Brasileira');
insert into tb_cozinha(nome_cozinha) values ('Italiana');
insert into tb_cozinha(nome_cozinha) values ('Tailandesa');

insert into tb_restaurante(nome) values ('Brasileira');
insert into tb_restaurante(nome) values ('Italiana');
insert into tb_restaurante(nome) values ('Tailandesa');
