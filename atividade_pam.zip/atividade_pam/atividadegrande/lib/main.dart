import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/add_task_screen.dart';

void main() => runApp(const ToDoApp());

class ToDoApp extends StatelessWidget {
  const ToDoApp({super.key});

  @override
  Widget build(BuildContext context){
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.amber),
      
      // TODO: implemente as rotas nomeadas para as telas HomeScreen e AddTaskScreen
      initialRoute: '/',
      routes: {
        '/': (context) => const HomeScreen(),
        '/adicionar': (context) => const AddTaskScreen()
      }

    );
  }
}