import 'package:flutter/material.dart';

class AddTaskScreen extends StatefulWidget {
  const AddTaskScreen({super.key});

  @override
  State<AddTaskScreen> createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends State<AddTaskScreen> {

  // Para controlar a entrada do campo de texto
  final TextEditingController _textController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text('Adicionar Tarefa'),
        backgroundColor: Colors.amber,
      ),

      // TODO: adicionar no body:
      //    - TextField e linkar com o _textController para adicionar uma nova tarefa.
      //    - ElevatedButton para adicionar a nova tarefa, ou seja, retornar o texto do 
      //      TextField para a tela anterior.
      body: Column(children: [
        TextField(
          controller: _textController,
        ),
        ElevatedButton(onPressed: () {
          if (!_textController.text.isEmpty){

          Navigator.pop(context, _textController.text);
          }
        }, child: Text('Adicionar uma lista'))
      ],),

    );
  }
}