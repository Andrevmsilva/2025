import 'package:flutter/material.dart';

/// TODO: implemente uma simples classe Task com os atributos title (String) e isDone (bool)
class Task {
  String titulo = "";
  bool isDone = false;
  Task (this.titulo);
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  // TODO: Criar uma lista vazia para armazenar nossas tarefas
  List<Task> _task = [];


// Navega para a tela de adicionar tarefa
void _navigateToAddTask() async {

  final newTaskTitle = await Navigator.pushNamed(context, '/adicionar');

  if (newTaskTitle != null){
    setState(() {
      // TODO: adicionar a nova Task na lista
        _task.add(Task('$newTaskTitle'));
    });
  }

}

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: Text('Lista de Tarefas'),
        backgroundColor: Colors.amber,
      ),
  
      // TODO: implementar no body um ListView.builder para exibir todas as tarefas da lista
     body: ListView.builder(itemCount:_task.length, itemBuilder:(BuildContext context, int index)
      {
        return ListTile(
          leading: Checkbox(value: value, onChanged: index),
          title: Text(_task[index].titulo)
          trailing: Text('depois'),
          );
        
        }
      
      ),

    floatingActionButton: FloatingActionButton(
      onPressed: () {
        // TODO: chamar a função
        _navigateToAddTask();

      },
      child: Icon(Icons.add)),

    );
  }
}